﻿### Internal ###############

[Guid]$OdmOrganization = [Guid]::Empty
[OdmProject]$OdmCurrentProject = $null

function Get-QmmpTypedEntity
{
    param(
        [string]$Entity,
        [object]$Filters,
        [Type]$Type,
        [Nullable[int]]$ResultSize
    )

    Get-QmmpEntity -Entity $Entity -Filters $Filters -ResultSize $ResultSize | QmmpCastEntityTo $Type
}

function Get-QmmpEntity
{
    param(
        [string]$Entity,
        [object]$Filters,
        [Nullable[int]]$ResultSize
    )

	$Body = @{ }

    if ($ResultSize)
    {
        $Body += @{ size = $ResultSize }
    }

    if ($Filters)
    {
        $Body += @{ query = @{ and = @($Filters) } }
    }

	$result = $null
	$getSize = 10000
	$gotCount = 0

	if ($ResultSize)
    {
        $getSize = [Math]::Min($getSize, $ResultSize)
    }

	for ($query = "$Entity/scroll?size=$getSize"; !$result -or $result.hits.hits.length -gt 0; $query = "scroll/$($result._scroll_id)")
	{
		$result = Invoke-QmmpApi -Entity $query -Method 'PUT' -Body $($local:Body | ConvertTo-Json -Depth 10)

		if ($ResultSize -and ($gotCount + $result.hits.hits.length -gt $ResultSize -or $gotCount + $result.hits.hits.length -eq $ResultSize))
		{
			$result.hits.hits | Select-Object -First ($ResultSize - $gotCount)

			break
		}
		else
		{
			$result.hits.hits
		}

		$gotCount += $result.hits.hits.length
	}
}

function QmmpCastEntityTo([Type]$Type)
{
    process
    {
        $res = [Newtonsoft.Json.JsonConvert]::DeserializeObject(($_._source | ConvertTo-Json -Depth 10), $Type)
        $res._Id = $_._Id
        $res.QmmpCustomDeserialize($_._source)
        $res
    }
}

function AddFilter([object]$PreCondition, [ScriptBlock]$Condition)
{
    if ($PreCondition)
    {
        & $Condition
    }
}

function AddWildcardFilter([Hashtable]$Filter)
{
    if ($Filter)
    {
        $Filter.Keys | %{ @{ wildcard = @{ "$_._raw" = $Filter[$_] } } }
    }
}

function FirstOfType([Type]$Type)
{
    process
    {
        $_ | Where-Object { $_ -and $_ -is $Type} | Select -First 1
    }
}

### Public ###############

function Select-OdmOrganization
{
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [Guid]$OrganizationId
    )

	if (CheckOrganizationExists($OrganizationId))
	{
		$script:OdmOrganization = $OrganizationId
		if (!(Get-OdmProject)) {throw $MessagesDictionary['OrganizationUnavailable']}
	}
	else
	{
		throw $MessagesDictionary['OrganizationUnavailable']
	}
}

function Get-OdmProject
{
    [CmdletBinding()]
    [OutputType([OdmProject])]
    param(
        [Parameter(Mandatory=$false, ValueFromPipeline=$true)]
        [OdmProject]$Project,
        [Parameter(Mandatory=$false)]
        [Hashtable]$WildcardFilter,
        [Parameter(Mandatory=$false)]
        [int]$ResultSize
    )

    process
    {
        if ($script:OdmOrganization -eq [Guid]::Empty)
		{
			throw $MessagesDictionary['SelectOrganization']
		}
		else
		{
			$filters = & {
				AddFilter $Project._Id { @{ term = @{ _id = $Project._Id } } }
				AddWildcardFilter $WildcardFilter
			}

			Get-QmmpTypedEntity -Entity 'projects' -Filters $filters -ResultSize $ResultSize -Type ([OdmProject])
		}
    }
}

function Select-OdmProject
{
    [CmdletBinding()]
    [OutputType([OdmProject])]
    param(
        [Parameter(Mandatory=$true, ValueFromPipeline=$true)]
        [OdmProject]$Project,
        [Parameter(Mandatory=$false)]
        [switch]$PassThru
    )

    if (!$Project.Name)
    {
        $Project = Get-OdmProject -Project $Project._Id
    }

	if (!$Project)
	{
		throw $MessagesDictionary['ProjectUnavailable']
	}
	else
	{
		$script:OdmCurrentProject = $Project

		if ($PassThru)
		{
			$script:OdmCurrentProject
		}
	}
}

function Get-OdmTask
{
    [CmdletBinding()]
    [OutputType([OdmTask])]
    param(
        [Parameter(Mandatory=$false, ValueFromPipeline=$true)]
        [OdmTask]$Task,
        [Parameter(Mandatory=$false)]
        [string]$Type,
        [Parameter(Mandatory=$false)]
        [Hashtable]$WildcardFilter,
        [Parameter(Mandatory=$false)]
        [int]$ResultSize
    )

    process
    {
        CheckProjectIsSet

        $filters = & {
            AddFilter $true		{ @{ term = @{ projectId = $script:OdmCurrentProject._Id } } }
            AddFilter $Task		{ @{ term = @{ _id = $Task._Id } } }
            AddFilter $Type		{ @{ term = @{ 'type._raw' = $Type } } }
            AddWildcardFilter	$WildcardFilter
        }

        Get-QmmpEntity -Entity 'tasks' -Filters $filters -ResultSize $ResultSize | ForEach-Object {
            $_ | QmmpCastEntityTo ($QmmpTaskTypeToTaskType[$_._source.type],[OdmTask] -ne $null)[0]
        }
    } 
}

function Get-OdmEvent
{
    [CmdletBinding()]
    [OutputType([OdmEvent])]
    param(
        [Parameter(Mandatory=$false, ValueFromPipeline=$true)]
        [object]$InputObject,
        [Parameter(Mandatory=$false)]
        [OdmObject]$Object,
        [Parameter(Mandatory=$false)]
        [OdmTask]$Task,
		[Parameter(Mandatory=$false)]
        [string]$Category,
        [Parameter(Mandatory=$false)]
        [DateTime]$From,
        [Parameter(Mandatory=$false)]
        [DateTime]$To,
        [Parameter(Mandatory=$false)]
        [string]$Severity,
        [Parameter(Mandatory=$false)]
        [switch]$CurrentOnly,
        [Parameter(Mandatory=$false)]
        [Hashtable]$WildcardFilter,
        [Parameter(Mandatory=$false)]
        [int]$ResultSize
    )
    process
    {
        CheckProjectIsSet

        $taskFilter = $Task, $InputObject | FirstOfType ([OdmTask])
        $objectFilter = $Object, $InputObject | FirstOfType ([OdmObject])
        
        $filters = & {
            AddFilter $true         { @{ term = @{ projectId = $script:OdmCurrentProject._Id } } }
            AddFilter $taskFilter   { @{ term = @{ taskId = $taskFilter._Id } } }
			AddFilter $Category		{ @{ term = @{ 'category._raw' = $Category } } }
            AddFilter $objectFilter { @{ term = @{ objectId = $objectFilter._Id } } }
            AddFilter $From         { @{ range = @{ timestamp = @{ gt = $From.ToUniversalTime().ToString('o') } } } }
            AddFilter $To           { @{ range = @{ timestamp = @{ lt = $To.ToUniversalTime().ToString('o') } } } }
            AddFilter $Severity     { @{ term = @{ 'severity._raw' = $Severity } } }
            AddFilter $CurrentOnly  { @{ not = @{ term = @{ obsolete = $true } } } }
            AddWildcardFilter $WildcardFilter
        }

        Get-QmmpTypedEntity -Entity 'events' -Filters $filters -ResultSize $ResultSize -Type ([OdmEvent])
    }
}

function Get-OdmObject
{
    [CmdletBinding()]
    [OutputType([OdmObject])]
    param(
        [Parameter(Mandatory=$false, ValueFromPipeline=$true)]
        [object]$InputObject,
        [Parameter(Mandatory=$false)]
        [OdmObject]$Object,
        [Parameter(Mandatory=$false)]
        [OdmTask]$Task,
        [Parameter(Mandatory=$false)]
        [OdmCollection]$Collection,
        [Parameter(Mandatory=$false)]
        [Hashtable]$WildcardFilter,
        [Parameter(Mandatory=$false)]
        [int]$ResultSize
    )

    process
    {
        CheckProjectIsSet

        $taskFilter = $Task, $InputObject | FirstOfType ([OdmTask])
        $collectionFilter = $Collection, $InputObject | FirstOfType ([OdmCollection])

        $filters = & {
            AddFilter $true             { @{ term = @{ projectId = $script:OdmCurrentProject._Id } } }
            AddFilter $Object           { @{ term = @{ _id = $Object._Id } } }
            AddFilter $taskFilter       { @{ nested = @{ path = 'tasks'; query = @{ term = @{ 'tasks.id' = $taskFilter._Id } } } } }
            AddFilter $collectionFilter { @{ term = @{ 'collections.id' = $collectionFilter._Id } } }
            AddWildcardFilter $WildcardFilter
        }

        Get-QmmpTypedEntity -Entity 'objects' -Filters $filters -ResultSize $ResultSize -Type ([OdmObject]) 
    }
}

function Get-OdmCollection
{
    [CmdletBinding()]
    [OutputType([OdmCollection])]
    param(
        [Parameter(Mandatory=$false, ValueFromPipeline=$true)]
        [OdmCollection]$Collection,
        [Parameter(Mandatory=$false)]
        [Hashtable]$WildcardFilter,
        [Parameter(Mandatory=$false)]
        [int]$ResultSize
    )

    process
    {
        CheckProjectIsSet

        $filters = & {
            AddFilter $true        { @{ term = @{ projectId = $script:OdmCurrentProject._Id } } }
            AddFilter $Collection  { @{ term = @{ _id = $Collection._Id } } }
            AddWildcardFilter $WildcardFilter
        }

        Get-QmmpTypedEntity -Entity 'collections' -Filters $filters -ResultSize $ResultSize -Type ([OdmCollection]) 
    }
}
# SIG # Begin signature block
# MIIOBwYJKoZIhvcNAQcCoIIN+DCCDfQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQU6l1wg9TR8YPhtuez3bh9ZkfE
# j8Sgggs9MIIFVTCCBD2gAwIBAgIRAOQ7pk6be99ARw7gugXITCQwDQYJKoZIhvcN
# AQELBQAwfTELMAkGA1UEBhMCR0IxGzAZBgNVBAgTEkdyZWF0ZXIgTWFuY2hlc3Rl
# cjEQMA4GA1UEBxMHU2FsZm9yZDEaMBgGA1UEChMRQ09NT0RPIENBIExpbWl0ZWQx
# IzAhBgNVBAMTGkNPTU9ETyBSU0EgQ29kZSBTaWduaW5nIENBMB4XDTE5MTAwMjAw
# MDAwMFoXDTIxMTAwMTIzNTk1OVowgZwxCzAJBgNVBAYTAlVTMQ4wDAYDVQQRDAU5
# MjY1NjETMBEGA1UECAwKQ2FsaWZvcm5pYTEUMBIGA1UEBwwLQWxpc28gVmllam8x
# FjAUBgNVBAkMDTQgUG9sYXJpcyBXYXkxHDAaBgNVBAoME1F1ZXN0IFNvZnR3YXJl
# IEluYy4xHDAaBgNVBAMME1F1ZXN0IFNvZnR3YXJlIEluYy4wggEiMA0GCSqGSIb3
# DQEBAQUAA4IBDwAwggEKAoIBAQC0QLBHHs0mb9AKSmxaUJ9vjDn5zvnhNZjHt3ud
# +qn8/yX1ddNp/eRflK1NWm6/RfIxjWfHl45rGRR3AlQKjR7CcxZsLBuhm449vlgA
# hIn5TNsFE8U/4V2m5YoVH9ET2TJgPEmUs9TsJwyA1YYWdVoZ4TfPMG7DHlpla1+R
# LKUeztF/UZm+q2qxYbSCaDZEiRaUEJ9TvgXa9eiQZOktAcoN9fuzuJW8HgHT6snH
# 2mzuJjR8JofbMm+APm3Qg3bMgGnlv1/UKu3TdniMwgwK2HZNf6qlhm5jP6s+256l
# 64GojJP4Z6HmWnFbVD0EXH7atY6s7l+Jz//d/6Y0adRGUpxJAgMBAAGjggGuMIIB
# qjAfBgNVHSMEGDAWgBQpkWD/ik366/mmarjP+eZLvUnOEjAdBgNVHQ4EFgQUbP9G
# anzu1CKGvG28iLn2zJdWfjcwDgYDVR0PAQH/BAQDAgeAMAwGA1UdEwEB/wQCMAAw
# EwYDVR0lBAwwCgYIKwYBBQUHAwMwEQYJYIZIAYb4QgEBBAQDAgQQMEAGA1UdIAQ5
# MDcwNQYMKwYBBAGyMQECAQMCMCUwIwYIKwYBBQUHAgEWF2h0dHBzOi8vc2VjdGln
# by5jb20vQ1BTMEMGA1UdHwQ8MDowOKA2oDSGMmh0dHA6Ly9jcmwuY29tb2RvY2Eu
# Y29tL0NPTU9ET1JTQUNvZGVTaWduaW5nQ0EuY3JsMHQGCCsGAQUFBwEBBGgwZjA+
# BggrBgEFBQcwAoYyaHR0cDovL2NydC5jb21vZG9jYS5jb20vQ09NT0RPUlNBQ29k
# ZVNpZ25pbmdDQS5jcnQwJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3NwLmNvbW9kb2Nh
# LmNvbTAlBgNVHREEHjAcgRptaWNoYWVsLmdvcm9jaGl0QHF1ZXN0LmNvbTANBgkq
# hkiG9w0BAQsFAAOCAQEADLM1M9Xa7P0bAl0U8XK+IH1RkQtIrQ9S/prL8oEgzKdZ
# zE9Q+eGUjxth0UeWje1PTRwMrU9Iu0JpiTyGsQf8+sVPm2Asg2eXKs7c+CuhRzfS
# e+HhaoKRGqC/1WNxQDeNwQbtqpLxwLukSnzTDZnCHB2bQGdJiER8+fQ6KwhxKvg8
# wZEWBs52s7U1jFu1mQsOOnXA9G0aFie1xaxN7XPny+6rsrgSeK6CGtTIwLW3VbgS
# bSPRB4IhGFzKxOuBYXLmmrX9m437MwBw9yiIOWoouGbK+Gc+2UcmzcVLvtdSj44B
# J9NcgGlzHH4P5mKDLN+gSroMm0TWOL+bg1y4B6hupDCCBeAwggPIoAMCAQICEC58
# h8wOk0pS/pT9HLfNNK8wDQYJKoZIhvcNAQEMBQAwgYUxCzAJBgNVBAYTAkdCMRsw
# GQYDVQQIExJHcmVhdGVyIE1hbmNoZXN0ZXIxEDAOBgNVBAcTB1NhbGZvcmQxGjAY
# BgNVBAoTEUNPTU9ETyBDQSBMaW1pdGVkMSswKQYDVQQDEyJDT01PRE8gUlNBIENl
# cnRpZmljYXRpb24gQXV0aG9yaXR5MB4XDTEzMDUwOTAwMDAwMFoXDTI4MDUwODIz
# NTk1OVowfTELMAkGA1UEBhMCR0IxGzAZBgNVBAgTEkdyZWF0ZXIgTWFuY2hlc3Rl
# cjEQMA4GA1UEBxMHU2FsZm9yZDEaMBgGA1UEChMRQ09NT0RPIENBIExpbWl0ZWQx
# IzAhBgNVBAMTGkNPTU9ETyBSU0EgQ29kZSBTaWduaW5nIENBMIIBIjANBgkqhkiG
# 9w0BAQEFAAOCAQ8AMIIBCgKCAQEAppiQY3eRNH+K0d3pZzER68we/TEds7liVz+T
# vFvjnx4kMhEna7xRkafPnp4ls1+BqBgPHR4gMA77YXuGCbPj/aJonRwsnb9y4+R1
# oOU1I47Jiu4aDGTH2EKhe7VSA0s6sI4jS0tj4CKUN3vVeZAKFBhRLOb+wRLwHD9h
# YQqMotz2wzCqzSgYdUjBeVoIzbuMVYz31HaQOjNGUHOYXPSFSmsPgN1e1r39qS/A
# JfX5eNeNXxDCRFU8kDwxRstwrgepCuOvwQFvkBoj4l8428YIXUezg0HwLgA3FLkS
# qnmSUs2HD3vYYimkfjC9G7WMcrRI8uPoIfleTGJ5iwIGn3/VCwIDAQABo4IBUTCC
# AU0wHwYDVR0jBBgwFoAUu69+Aj36pvE8hI6t7jiY7NkyMtQwHQYDVR0OBBYEFCmR
# YP+KTfrr+aZquM/55ku9Sc4SMA4GA1UdDwEB/wQEAwIBhjASBgNVHRMBAf8ECDAG
# AQH/AgEAMBMGA1UdJQQMMAoGCCsGAQUFBwMDMBEGA1UdIAQKMAgwBgYEVR0gADBM
# BgNVHR8ERTBDMEGgP6A9hjtodHRwOi8vY3JsLmNvbW9kb2NhLmNvbS9DT01PRE9S
# U0FDZXJ0aWZpY2F0aW9uQXV0aG9yaXR5LmNybDBxBggrBgEFBQcBAQRlMGMwOwYI
# KwYBBQUHMAKGL2h0dHA6Ly9jcnQuY29tb2RvY2EuY29tL0NPTU9ET1JTQUFkZFRy
# dXN0Q0EuY3J0MCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5jb21vZG9jYS5jb20w
# DQYJKoZIhvcNAQEMBQADggIBAAI/AjnD7vjKO4neDG1NsfFOkk+vwjgsBMzFYxGr
# CWOvq6LXAj/MbxnDPdYaCJT/JdipiKcrEBrgm7EHIhpRHDrU4ekJv+YkdK8eexYx
# biPvVFEtUgLidQgFTPG3UeFRAMaH9mzuEER2V2rx31hrIapJ1Hw3Tr3/tnVUQBg2
# V2cRzU8C5P7z2vx1F9vst/dlCSNJH0NXg+p+IHdhyE3yu2VNqPeFRQevemknZZAp
# QIvfezpROYyoH3B5rW1CIKLPDGwDjEzNcweU51qOOgS6oqF8H8tjOhWn1BUbp1JH
# Mqn0v2RH0aofU04yMHPCb7d4gp1c/0a7ayIdiAv4G6o0pvyM9d1/ZYyMMVcx0Dbs
# R6HPy4uo7xwYWMUGd8pLm1GvTAhKeo/io1Lijo7MJuSy2OU4wqjtxoGcNWupWGFK
# Cpe0S0K2VZ2+medwbVn4bSoMfxlgXwyaiGwwrFIJkBYb/yud29AgyonqKH4yjhnf
# e0gzHtdl+K7J+IMUk3Z9ZNCOzr41ff9yMU2fnr0ebC+ojwwGUPuMJ7N2yfTm18M0
# 4oyHIYZh/r9VdOEhdwMKaGy75Mmp5s9ZJet87EUOeWZo6CLNuO+YhU2WETwJitB/
# vCgoE/tqylSNklzNwmWYBp7OSFvUtTeTRkF8B93P+kPvumdh/31J4LswfVyA4+YW
# OUunMYICNDCCAjACAQEwgZIwfTELMAkGA1UEBhMCR0IxGzAZBgNVBAgTEkdyZWF0
# ZXIgTWFuY2hlc3RlcjEQMA4GA1UEBxMHU2FsZm9yZDEaMBgGA1UEChMRQ09NT0RP
# IENBIExpbWl0ZWQxIzAhBgNVBAMTGkNPTU9ETyBSU0EgQ29kZSBTaWduaW5nIENB
# AhEA5DumTpt730BHDuC6BchMJDAJBgUrDgMCGgUAoHgwGAYKKwYBBAGCNwIBDDEK
# MAigAoAAoQKAADAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgorBgEEAYI3
# AgELMQ4wDAYKKwYBBAGCNwIBFTAjBgkqhkiG9w0BCQQxFgQUWBkqCBs6MSSv+sBs
# RTCjwVeS2UMwDQYJKoZIhvcNAQEBBQAEggEAQcIMClCyXIc4aTTraLWAXEGhN7RA
# chcUa686NM959sUbU5NoAAX7KY2MtaTnRvR1YQLXQr26ZRcFyb9hCEPK/MTJpmxD
# J4FpomUxo0bcw3SZV2UW/BTDK0iput2J/aP3UopR5JiXuD3fCxnL1yP8IxxfBM1/
# 6iTQHDsGa+1TiV/9gUXZbN0YyfxH88kZnFfiwbfl6fqjKpj+8T+pUN0mwPdRDN0O
# w5s3xCWMo0Y0jtgk3c4pjzmoXuIUWASodkt4LsgVgEndj6lcAob95DpCdbZpgRm1
# IZjkXPa/18YitYX5C3ldJACc26mB4M6vbpAGrIcRCJGmoe5Xw9xmuhP05Q==
# SIG # End signature block
