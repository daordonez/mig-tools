﻿### Types ###############

class OdmEntity
{
    [Newtonsoft.Json.JsonPropertyAttribute('_id')]
	[Newtonsoft.Json.JsonIgnoreAttribute()]
    [string]$_Id

    hidden [void] QmmpCustomDeserialize([object]$source)
    {
    }

	OdmEntity()
    {
    }

    OdmEntity($id)
    {
        $this._Id = $id
    }
}

class OdmObjectTask
{
	[Newtonsoft.Json.JsonPropertyAttribute('id')]
    [string]$Id

	[Newtonsoft.Json.JsonPropertyAttribute('status')]
    [string]$Status
}

class OdmSchedule
{
    OdmSchedule()
    {
        $this.Cron = $null
        $this.EndTime = $null
        $this.StartTime = $null
    }

    OdmSchedule($startTime)
    {
        $this.Cron = $null
        $this.EndTime = $null
        $this.StartTime = $startTime
    }

    [Newtonsoft.Json.JsonPropertyAttribute('cron')]
    [string]$Cron

    [Newtonsoft.Json.JsonPropertyAttribute('endTime')]
    [Nullable[DateTime]]$EndTime

    [Newtonsoft.Json.JsonPropertyAttribute('startTime')]
    [Nullable[DateTime]]$StartTime
}

enum RunTaskEnum
{
    Now
    Later
    Schedule
}

enum O365LicenseAssignmentTypeEnum
{
    Keep
    Replace
}

enum AddressRewritingActionEnum
{
    Deploy
	DeployReverse
    Enable
    Disable
    AddUsers
    RemoveUsers
}

enum MatchingActionEnum
{
    MatchingBreak
    Matching
}

enum MatchingAttributeEnum
{
    DisplayName
    Mail
    MailNickname
    ImmutableId
    EmployeeId
}

enum SwitchDirectionEnum
{
    SourceToTarget
    TargetToSource
}

enum OneDriveFileVersionsEnum
{
    Latest
    LatestAndPrevious
    All
}

enum OneDriveMigrationActionEnum
{
    Overwrite
    Skip
}

enum OneDrivePermissionBehaviourEnum
{
    NoPermission
    MigratedContentOnly
    All
}

enum OneDriveAuthorEnum
{
    SystemAccount
    TargetAccount
}

enum DomainCoexistenceExchangeRulesStateEnum
{
    Failed
    Applying
    Applied
}

class OdmProject: OdmEntity
{
    OdmProject($id)
    {
        $this._Id = $id
    }

    [Newtonsoft.Json.JsonPropertyAttribute('name')]
    [string]$Name
    [Newtonsoft.Json.JsonPropertyAttribute('stage')]
    hidden [string]$Stage
    [Newtonsoft.Json.JsonPropertyAttribute('cuaThumbprint')]
    hidden [string]$CertificateThumbprint
    [Newtonsoft.Json.JsonPropertyAttribute('description')]
    [string]$Description

	[Newtonsoft.Json.JsonIgnoreAttribute()]
    [string]$SourceTenantDefaultDomainName
	[Newtonsoft.Json.JsonIgnoreAttribute()]
    [string]$TargetTenantDefaultDomainName

	[Newtonsoft.Json.JsonPropertyAttribute('coexistenceAction')]
	hidden [string]$CoexistenceAction

    [Newtonsoft.Json.JsonPropertyAttribute('hybridEnabled')]
    hidden [Nullable[bool]]$HybridEnabled

    [string] ToString()
    {
        return $this.Name
    }

	hidden [void] QmmpCustomDeserialize([object]$source)
    {
		$this.SourceTenantDefaultDomainName = $source.sourceTenant.defaultDomainName
		$this.TargetTenantDefaultDomainName = $source.targetTenant.defaultDomainName
    }
}

class OdmCollection: OdmEntity
{
    OdmCollection()
    {
    }

    OdmCollection($id)
    {
        $this._Id = $id
    }

    [Newtonsoft.Json.JsonPropertyAttribute('name')]
    [string]$Name
	[Newtonsoft.Json.JsonPropertyAttribute('projectId')]
    hidden [string]$ProjectId

    [string] ToString()
    {
        return $this.Name
    }
}

class OdmTask: OdmEntity
{
    OdmTask()
    {
    }

    OdmTask($id)
    {
        $this._Id = $id
    }

    [Newtonsoft.Json.JsonPropertyAttribute('projectId')]
    hidden [string]$ProjectId
    [Newtonsoft.Json.JsonPropertyAttribute('name')]
    [string]$Name
    [Newtonsoft.Json.JsonPropertyAttribute('type')]
    [string]$Type
	[Newtonsoft.Json.JsonPropertyAttribute('hidden')]
    hidden [Nullable[bool]]$Hidden
    [Nullable[DateTime]]$Created
    [Nullable[DateTime]]$Modified

    [Newtonsoft.Json.JsonPropertyAttribute('runTask')]
    hidden [string]$Run
	[Newtonsoft.Json.JsonPropertyAttribute('schedule')]
    hidden [OdmSchedule]$Schedule

    [Newtonsoft.Json.JsonPropertyAttribute('status')]
    [string]$Status
    [Newtonsoft.Json.JsonPropertyAttribute('progress')]
    [Nullable[int]]$Progress
    [Newtonsoft.Json.JsonPropertyAttribute('lastResultDescription')]
    [string]$LastResult

    [string] ToString()
    {
        return $this.Name
    }

	[bool] ShouldSerializeHidden()
    {
        return $this.Hidden
    }
	
	[bool] ShouldSerializeCreated()
    {
        return $false
    }

	[bool] ShouldSerializeModified()
    {
        return $false
    }

	[bool] ShouldSerializeProgress()
    {
        return $false
    }

    [bool] ShouldSerializeLastResult()
    {
        return $this.LastResult
    }

    [bool] ShouldSerializeSchedule()
    {
        return $($this.Schedule -ne $null -and $this.Schedule.StartTime -ne $null)
    }

    [bool] ShouldSerializeStatus()
    {
        return $this.Status
    }
}

class OdmAddressRewritingTask: OdmTask
{
    [Newtonsoft.Json.JsonPropertyAttribute('coexistenceAction')]
    [string]$Action
    [Newtonsoft.Json.JsonPropertyAttribute('coexistenceStatusExRules')]
    [string]$ExchangeRulesState
	[Newtonsoft.Json.JsonPropertyAttribute('sourceConnectionId')]
	hidden [string]$SourceConnectionId
	[Newtonsoft.Json.JsonPropertyAttribute('targetConnectionId')]
	hidden [string]$TargetConnectionId
}

class OdmMatchingTask: OdmTask
{
    [Newtonsoft.Json.JsonPropertyAttribute('matchingAction')]
    [string]$MatchingAction
    [Newtonsoft.Json.JsonPropertyAttribute('srcmatchattr')]
    hidden [string]$SourceAttribute
    [Newtonsoft.Json.JsonPropertyAttribute('trgmatchattr')]
    hidden [string]$TargetAttribute
	[Newtonsoft.Json.JsonPropertyAttribute('targetConnectionId')]
    hidden [string]$TargetConnectionId

    [bool] ShouldSerializeSourceAttribute()
    {
        return $this.SourceAttribute
    }

    [bool] ShouldSerializeTargetAttribute()
    {
        return $this.TargetAttribute
    }
}

class OdmMigrationTask: OdmTask
{
    [Newtonsoft.Json.JsonPropertyAttribute('targetDomain')]
    [string]$TargetUpnSuffix
    [Newtonsoft.Json.JsonPropertyAttribute('onPremTargetOu')]
    hidden [string]$TargetOnPremisesOU
	[Newtonsoft.Json.JsonPropertyAttribute('targetConnectionId')]
	hidden [string]$TargetConnectionId
}

class OdmDiscoveryTask: OdmTask
{
    [Newtonsoft.Json.JsonPropertyAttribute('DiscoverMailboxes')]
    [Nullable[bool]]$IncludeMailboxDetails
    [Newtonsoft.Json.JsonPropertyAttribute('discoverUsingCSV')]
    [string]$DiscoverUsingCSV
    [Newtonsoft.Json.JsonPropertyAttribute('discoverMatchingFile')]
    hidden [object]$DiscoverMatchingFile
    [Newtonsoft.Json.JsonPropertyAttribute('sourceConnectionId')]
    hidden [string]$SourceConnectionId
    [Newtonsoft.Json.JsonPropertyAttribute('targetConnectionId')]
    hidden [string]$TargetConnectionId
    hidden [void] QmmpCustomDeserialize([object]$source = $null)
    {
        if ($source -ne $null)
        {
            $this.DiscoverMatchingFile = @{
                Id = $source.DiscoverMatchingFile.id
                Url = $source.DiscoverMatchingFile.url
                FileName = $source.DiscoverMatchingFile.filename
            }
        }
    }
}

class OdmOneDriveMigrationTask: OdmTask
{
    [Newtonsoft.Json.JsonPropertyAttribute('fileVersionMigrationBehavior')]
    [string]$FileVersions
    [Newtonsoft.Json.JsonPropertyAttribute('fileMigrationAction')]
    [string]$MigrationAction

    [Newtonsoft.Json.JsonPropertyAttribute('licenseForTarget')]
    [string]$O365LicenseToAssign
    [Newtonsoft.Json.JsonPropertyAttribute('azureSkuAssignmentBehaviour')]
    [string]$O365LicenseAssignmentType
    [Newtonsoft.Json.JsonPropertyAttribute('overrideUsageLocation')]
    hidden [Nullable[bool]]$OverrideUsageLocation
    [Newtonsoft.Json.JsonPropertyAttribute('usageLocation')]
    hidden [string]$UsageLocation

    [Newtonsoft.Json.JsonPropertyAttribute('onedrivePermissionBehaviour')]
    [string]$PermissionBehaviour

    [Newtonsoft.Json.JsonPropertyAttribute('onedriveMigrateLinkPermission')]
    [Nullable[bool]]$MigrateLinkPermission

    [Newtonsoft.Json.JsonPropertyAttribute('oneDrivePermissionsInRerun')]
    [Nullable[bool]]$PermissionsInRerun

    [Newtonsoft.Json.JsonPropertyAttribute('onedriveAuthor')]
    [string]$Author

    [Newtonsoft.Json.JsonPropertyAttribute('fileVersionMaxSize')]
    [long]$FileVersionMaxSize

    [Newtonsoft.Json.JsonPropertyAttribute('oneDriveRerunIfMissingItems')]
    [Nullable[bool]]$RerunIfMissingItems

    [Newtonsoft.Json.JsonPropertyAttribute('onedriveExcludeSpecificFolders')]
    hidden [string]$ExcludeFolders
    [Newtonsoft.Json.JsonPropertyAttribute('onedriveExcludeSpecificFileExtensions')]
    hidden [string]$ExcludeFileTypes

    [Newtonsoft.Json.JsonPropertyAttribute('onedriveExcludeFileBefore')]
    hidden [Nullable[DateTime]]$ExcludeCreatedBefore
    [Newtonsoft.Json.JsonPropertyAttribute('onedriveExcludeFileAfter')]
    hidden [Nullable[DateTime]]$ExcludeModifiedAfter

    [Newtonsoft.Json.JsonPropertyAttribute('onedriveExcludeFileMaxSize')]
    hidden [Nullable[long]]$ExcludeBiggerThan

	[Newtonsoft.Json.JsonPropertyAttribute('targetConnectionId')]
	hidden [string]$TargetConnectionId
}

class OdmOneDriveStatisticsTask: OdmTask
{
}

class OdmMailMigrationTask: OdmTask
{
    [Newtonsoft.Json.JsonPropertyAttribute('odmeMigrateFromArchive')]
    hidden [string]$MigrateFromArchive
    [Newtonsoft.Json.JsonPropertyAttribute('odmeMigrateToArchive')]
    hidden [string]$MigrateToArchive

    [Newtonsoft.Json.JsonPropertyAttribute('odmeMigrateEmail')]
    [Nullable[bool]]$MigrateMail
    [Newtonsoft.Json.JsonPropertyAttribute('odmeMigrateCalendar')]
    [Nullable[bool]]$MigrateCalendar
    [Newtonsoft.Json.JsonPropertyAttribute('odmeMigrateContacts')]
    [Nullable[bool]]$MigrateContacts
    [Newtonsoft.Json.JsonPropertyAttribute('odmeMigrateTasks')]
    [Nullable[bool]]$MigrateTasks
    [Newtonsoft.Json.JsonPropertyAttribute('odmeMigrateRules')]
    [Nullable[bool]]$MigrateRules

    [Newtonsoft.Json.JsonPropertyAttribute('odmeMigrateRecoverableItems')]
    [Nullable[bool]]$MigrateRecoverableItems

    [Newtonsoft.Json.JsonPropertyAttribute('odmeMigrateDelegates')]
    [Nullable[bool]]$MigrateDelegates
    [Newtonsoft.Json.JsonPropertyAttribute('odmeMigrateFolderPermissions')]
    [Nullable[bool]]$MigrateFolderPermissions

    [Newtonsoft.Json.JsonPropertyAttribute('odmeExcludeDeletedMail')]
    hidden [Nullable[bool]]$ExcludeDeletedItems
    [Newtonsoft.Json.JsonPropertyAttribute('odmeExcludeJunkMail')]
    hidden [Nullable[bool]]$ExcludeJunkEmail
    [Newtonsoft.Json.JsonPropertyAttribute('odmeExcludeSentMail')]
    hidden [Nullable[bool]]$ExcludeSentItems
    [Newtonsoft.Json.JsonPropertyAttribute('odmeExcludeInboxEmail')]
    hidden [Nullable[bool]]$ExcludeInbox
    [Newtonsoft.Json.JsonPropertyAttribute('odmeExcludeDraftsEmail')]
    hidden [Nullable[bool]]$ExcludeDrafts
    [Newtonsoft.Json.JsonPropertyAttribute('odmeExcludeConversationHistoryEmail')]
    hidden [Nullable[bool]]$ExcludeConversationHistory
    [Newtonsoft.Json.JsonPropertyAttribute('odmeIncludeInboxEmail')]
    hidden [Nullable[bool]]$IncludeInbox
    [Newtonsoft.Json.JsonPropertyAttribute('odmeIncludeSentEmail')]
    hidden [Nullable[bool]]$IncludeSentItems
    [Newtonsoft.Json.JsonPropertyAttribute('odmeIncludeDeletedEmail')]
    hidden [Nullable[bool]]$IncludeDeletedItems
    [Newtonsoft.Json.JsonPropertyAttribute('odmeIncludeDraftsEmail')]
    hidden [Nullable[bool]]$IncludeDrafts
    [Newtonsoft.Json.JsonPropertyAttribute('odmeExcludeMailAfter')]
    hidden [Nullable[DateTime]]$MigrateMailUntil
    [Newtonsoft.Json.JsonPropertyAttribute('odmeExcludeMailBefore')]
    hidden [Nullable[DateTime]]$MigrateMailFrom
    [Newtonsoft.Json.JsonPropertyAttribute('odmeExcludeSpecificFolders')]
    hidden [string]$ExcludeMailFolders
    [Newtonsoft.Json.JsonPropertyAttribute('odmeIncludeSpecificFolders')]
    hidden [string]$IncludeMailFolders

    [Newtonsoft.Json.JsonPropertyAttribute('odmeSetLicense')]
    [bool]$AssignO365License
    [Newtonsoft.Json.JsonPropertyAttribute('licenseForTarget')]
    [string]$O365LicenseToAssign
    [Newtonsoft.Json.JsonPropertyAttribute('azureSkuAssignmentBehaviour')]
    [string]$O365LicenseAssignmentType
    [Newtonsoft.Json.JsonPropertyAttribute('overrideUsageLocation')]
    hidden [Nullable[bool]]$OverrideUsageLocation
    [Newtonsoft.Json.JsonPropertyAttribute('usageLocation')]
    hidden [string]$UsageLocation

    [Newtonsoft.Json.JsonPropertyAttribute('odmeForwardingAction')]
    hidden [int]$ForwardingAction
    [Newtonsoft.Json.JsonPropertyAttribute('odmeTargetForwardingDomain')]
    hidden [string]$TargetForwardingDomain
    [Newtonsoft.Json.JsonPropertyAttribute('odmeSourceForwardingDomain')]
    hidden [string]$SourceForwardingDomain
    [Newtonsoft.Json.JsonPropertyAttribute('odmeForwardingDirection')]
    hidden [int]$ForwardingDirection
    [Newtonsoft.Json.JsonPropertyAttribute('odmeEnableForwarding')]
    hidden [bool]$EnableForwarding
    [Newtonsoft.Json.JsonPropertyAttribute('targetConnectionId')]
    hidden [string]$TargetConnectionId

    [Newtonsoft.Json.JsonIgnoreAttribute()]
    [string]$MailForwarding
    [Newtonsoft.Json.JsonPropertyAttribute('default_MailForwarding')]
    hidden [Nullable[bool]]$Default_MailForwarding
    [Newtonsoft.Json.JsonPropertyAttribute('enable_MailForwarding')]
    hidden [string]$Enable_MailForwarding

    [Newtonsoft.Json.JsonPropertyAttribute('odmeAllowMapping')]
    hidden [Nullable[bool]]$AllowFolderMapping
    [Newtonsoft.Json.JsonPropertyAttribute('odmeInboxMappingFolderName')]
    hidden [string]$InboxMappingFolderName
    [Newtonsoft.Json.JsonPropertyAttribute('odmeDeletedMappingFolderName')]
    hidden [string]$DeletedMappingFolderName
    [Newtonsoft.Json.JsonPropertyAttribute('odmeArchiveMappingFolderName')]
    hidden [string]$ArchiveMappingFolderName
    [Newtonsoft.Json.JsonPropertyAttribute('odmeSentItemsMappingFolderName')]
    hidden [string]$SentItemsMappingFolderName

    [bool] ShouldSerializeMigrateMailUntil()
    {
        return $this.MigrateMailUntil
    }

    [bool] ShouldSerializeMigrateMailFrom()
    {
        return $this.MigrateMailFrom
    }

    hidden [void] QmmpCustomDeserialize([object]$source)
    {
        if($this.Default_MailForwarding -and ($this.Enable_MailForwarding -eq "true")) {
            $this.MailForwarding = "Enable"
        }
        elseif($this.Default_MailForwarding -and ($this.Enable_MailForwarding -eq "false")) {
            $this.MailForwarding = "Disable"
        }
        elseif((-not $this.Default_MailForwarding) -and ($this.Enable_MailForwarding -eq "false")) {
            $this.MailForwarding = "Ignore"
        }
    }
}

class OdmMailSwitchTask: OdmTask
{
    [Newtonsoft.Json.JsonPropertyAttribute('switchDirection')]
    [string]$SwitchDirection
    [Newtonsoft.Json.JsonPropertyAttribute('odmeTargetForwardingDomain')]
    [string]$ForwardingDomain
	[Newtonsoft.Json.JsonPropertyAttribute('originNeedNotify')]
    [Nullable[bool]]$NotifyOrigin
	[Newtonsoft.Json.JsonPropertyAttribute('originNotificationFromEmail')]
    [string]$OriginNotificationFromEmail
	[Newtonsoft.Json.JsonPropertyAttribute('originNotificationFromDisplayName')]
    [string]$OriginNotificationFromDisplayName
	[Newtonsoft.Json.JsonPropertyAttribute('originNotificationSubject')]
    [string]$OriginNotificationSubject
	[Newtonsoft.Json.JsonPropertyAttribute('originNotificationMessage')]
    [string]$OriginNotificationMessage
	[Newtonsoft.Json.JsonPropertyAttribute('destinationNeedNotify')]
    [Nullable[bool]]$NotifyDestination
	[Newtonsoft.Json.JsonPropertyAttribute('destinationNotificationFromEmail')]
    [string]$DestinationNotificationFromEmail
	[Newtonsoft.Json.JsonPropertyAttribute('destinationNotificationFromDisplayName')]
    [string]$DestinationNotificationFromDisplayName
	[Newtonsoft.Json.JsonPropertyAttribute('destinationNotificationSubject')]
    [string]$DestinationNotificationSubject
	[Newtonsoft.Json.JsonPropertyAttribute('destinationNotificationMessage')]
    [string]$DestinationNotificationMessage
	[Newtonsoft.Json.JsonPropertyAttribute('targetConnectionId')]
	hidden [string]$TargetConnectionId
}

class OdmCalendarSharingTask: OdmTask
{
    [Newtonsoft.Json.JsonPropertyAttribute('sourceDomain')]
    [string]$SourceDomain
    [Newtonsoft.Json.JsonPropertyAttribute('targetDomain')]
    [string]$TargetDomain
	[Newtonsoft.Json.JsonPropertyAttribute('sourceConnectionId')]
	hidden [string]$SourceConnectionId
	[Newtonsoft.Json.JsonPropertyAttribute('targetConnectionId')]
	hidden [string]$TargetConnectionId
}

class OdmMappingFileTask: OdmTask
{
    [Newtonsoft.Json.JsonPropertyAttribute('matchingAction')]
    [string]$MatchingAction
    [Newtonsoft.Json.JsonPropertyAttribute('matchingFile')]
    hidden [object]$MatchingFile
	[Newtonsoft.Json.JsonPropertyAttribute('targetConnectionId')]
    hidden [string]$TargetConnectionId

    hidden [void] QmmpCustomDeserialize([object]$source)
    {
        $this.MatchingFile = @{
            Id = $source.matchingFile.id
            Url = $source.matchingFile.url
            FileName = $source.matchingFile.filename
        }
    }
}

class OdmCopyPermissionTask: OdmTask
{
	[Newtonsoft.Json.JsonPropertyAttribute('ProcessSharepoint')]
    [Nullable[bool]]$ProcessSharePoint
    [Newtonsoft.Json.JsonPropertyAttribute('transferPermissionsFile')]
    hidden [object]$TransferPermissionsFile
	[Newtonsoft.Json.JsonPropertyAttribute('sharepointMultipleUrlFile')]
    hidden [object]$SharepointMultipleUrlFile
	[Newtonsoft.Json.JsonPropertyAttribute('sharepointurl')]
    [string]$SharePointSiteUrl
	[Newtonsoft.Json.JsonPropertyAttribute('ProcessMultipleSharepointSites')]
    [string]$ProcessMultipleSharepointSites

    hidden [void] QmmpCustomDeserialize([object]$source)
    {
        $this.TransferPermissionsFile = @{
            Id = $source.transferPermissionsFile.id
            Url = $source.transferPermissionsFile.url
            FileName = $source.transferPermissionsFile.filename
        }
		
		$this.SharepointMultipleUrlFile = @{
            Id = $source.sharepointMultipleUrlFile.id
            Url = $source.sharepointMultipleUrlFile.url
            FileName = $source.sharepointMultipleUrlFile.filename
        }
    }
}

class OdmProcessingTask: OdmTask
{
    [Newtonsoft.Json.JsonPropertyAttribute('ProcessApps')]
    [Nullable[bool]]$ProcessApplications
    [Newtonsoft.Json.JsonPropertyAttribute('ProcessRoles')]
    [Nullable[bool]]$ProcessRoles
    [Newtonsoft.Json.JsonPropertyAttribute('ProcessSharepoint')]
    [Nullable[bool]]$ProcessSharePoint
    [Newtonsoft.Json.JsonPropertyAttribute('sharepointurl')]
    [string]$SharePointSiteUrl
}

class OdmEvent: OdmEntity
{
    hidden [string]$ProjectId
    [string]$TaskId
    [string]$ObjectId
    [Nullable[DateTime]]$Timestamp
    [string]$Severity
    [string]$Category
    [string]$Message
    [string]$Details
    [string]$TaskName
    [string]$ObjectName

    [string] ToString()
    {
        return $this.Message
    }

    hidden [void] QmmpCustomDeserialize([object]$source)
    {
        $this.TaskName = $source.task.name
        $this.ObjectName = $source.object.name
    }
}

class OdmObject: OdmEntity
{
    OdmObject()
    {
    }

    OdmObject($id)
    {
        $this._Id = $id
    }

    hidden [string]$ProjectId
    [string]$FirstName
    [string]$SecondName
    [string]$DisplayName
    [string]$Type
    [string]$UserType
    [string]$RecipientTypeDetails
    [string]$GroupType
    [Newtonsoft.Json.JsonPropertyAttribute('isTeamGroup')]
    hidden [Nullable[bool]]$IsTeamGroup
    [Newtonsoft.Json.JsonPropertyAttribute('sourceAzureId')]
    [Nullable[Guid]]$SourceGuid
    [string]$SourceEmail
    [Newtonsoft.Json.JsonPropertyAttribute('userPrincipalName')]
    [string]$SourceUserPrincipalName
    [Nullable[int]]$Progress
    [string]$Status
    [Newtonsoft.Json.JsonPropertyAttribute('targetAzureId')]
    [Nullable[Guid]]$TargetGuid
    [Newtonsoft.Json.JsonPropertyAttribute('targetEmail')]
    [string]$TargetEmail
    [Newtonsoft.Json.JsonPropertyAttribute('targetUserPrincipalName')]
    [string]$TargetUserPrincipalName
    hidden [Nullable[bool]]$IsOnPremSyncEnabled
    hidden [string]$SourceOnPremId
    hidden [string]$TargetOnPremId

    [Newtonsoft.Json.JsonPropertyAttribute('mailboxStatus')]
    [string]$MailboxStatus
    [Newtonsoft.Json.JsonPropertyAttribute('odmeStatus')]
    [string]$MailMigrationStatus
    [Newtonsoft.Json.JsonPropertyAttribute('odmeProgress')]
    [Nullable[int]]$MailMigrationProgress
    [Newtonsoft.Json.JsonPropertyAttribute('odmeEstimated')]
    [Nullable[int]]$MailMigrationEstimated
    [Newtonsoft.Json.JsonPropertyAttribute('odmeProcessed')]
    [Nullable[int]]$MailMigrationProcessed
    [Newtonsoft.Json.JsonPropertyAttribute('odmeErrors')]
    [Nullable[int]]$MailMigrationErrors

    [Newtonsoft.Json.JsonPropertyAttribute('archiveMailboxStatus')]
    [string]$ArchiveMailboxStatus
    [Newtonsoft.Json.JsonPropertyAttribute('odmeEstimatedArchive')]
    [Nullable[int]]$ArchiveMailMigrationEstimated
    [Newtonsoft.Json.JsonPropertyAttribute('odmeProcessedArchive')]
    [Nullable[int]]$ArchiveMailMigrationProcessed

    [Newtonsoft.Json.JsonPropertyAttribute('switchStatus')]
    [string]$SwitchStatus
    [Newtonsoft.Json.JsonPropertyAttribute('mailboxSwitch')]
    [string]$SwitchDirection

    [string]$OneDriveStatus
    [Nullable[int]]$OneDriveProgress
    [Newtonsoft.Json.JsonPropertyAttribute('oneDriveSourceFileCount')]
    [Nullable[int]]$OneDriveSourceFileCount
    [Newtonsoft.Json.JsonPropertyAttribute('oneDriveSourceItemCount')]
    [Nullable[int]]$OneDriveSourceItemCount
    [Newtonsoft.Json.JsonPropertyAttribute('oneDriveTargetItemCount')]
    [Nullable[int]]$OneDriveTargetItemCount
    [Newtonsoft.Json.JsonPropertyAttribute('oneDriveMigrationProgress')]
    [Nullable[double]]$OneDriveMigrationProgress
    [Newtonsoft.Json.JsonPropertyAttribute('oneDriveProvisioned')]
    [Nullable[bool]]$OneDriveProvisioned
    [Newtonsoft.Json.JsonPropertyAttribute('oneDriveAssessmentStatus')]
    [string]$OneDriveAssessmentStatus
    [Newtonsoft.Json.JsonPropertyAttribute('oneDriveSourceTotalSize')]
    [Nullable[long]]$OneDriveSourceTotalSize
    hidden [string]$Name
    [string]$JobTitle
    [string]$Department
    [string]$Country
    [string]$City
    [Newtonsoft.Json.JsonPropertyAttribute('isAccountEnabled')]	
    hidden [string]$IsAccountEnabled
    hidden [string]$PasswordPolicies
    hidden [string]$AssignedLicenses

    [string]$MailboxPropsDiscovered
    [Newtonsoft.Json.JsonPropertyAttribute('isMailbox')]
    hidden [Nullable[bool]]$IsMailbox
    [Newtonsoft.Json.JsonPropertyAttribute('lastLogonTime')]
    [Nullable[DateTime]]$MailboxLogonTime
    [Nullable[long]]$MailboxSize
    [Newtonsoft.Json.JsonPropertyAttribute('itemCount')]
    [Nullable[long]]$MailboxItemsCount
    [Nullable[Guid]]$ArchiveGuid

    hidden [string]$ConnectionId
    [Newtonsoft.Json.JsonPropertyAttribute('sourceConnectionId')]
    hidden [string]$SourceConnectionId
    [Newtonsoft.Json.JsonPropertyAttribute('targetConnectionId')]
    hidden [string]$TargetConnectionId
    [Newtonsoft.Json.JsonPropertyAttribute('addressRewrite')]
    hidden [string]$AddressRewrite
    [Newtonsoft.Json.JsonPropertyAttribute('addressRewriteStatus')]
    hidden [string]$AddressRewriteStatus
    hidden [OdmObjectTask[]]$Tasks

    [string] ToString()
    {
        return $this.Name
    }
}

enum UsageLocation
{
    AF
    AX
    AL
    DZ
    AS
    AD
    AO
    AI
    AQ
    AG
    AR
    AM
    AW
    AU
    AT
    AZ
    BS
    BH
    BD
    BB
    BY
    BE
    BZ
    BJ
    BM
    BT
    BO
    BQ
    BA
    BW
    BV
    BR
    IO
    BN
    BG
    BF
    BI
    KH
    CM
    CA
    CV
    KY
    CF
    TD
    CL
    CN
    CX
    CC
    CO
    KM
    CG
    CD
    CK
    CR
    CI
    HR
    CU
    CW
    CY
    CZ
    DK
    DJ
    DM
    DO
    EC
    EG
    SV
    GQ
    ER
    EE
    ET
    FK
    FO
    FJ
    FI
    FR
    GF
    PF
    TF
    GA
    GM
    GE
    DE
    GH
    GI
    GR
    GL
    GD
    GP
    GU
    GT
    GG
    GN
    GW
    GY
    HT
    HM
    VA
    HN
    HK
    HU
    IS
    IN
    ID
    IQ
    IE
    IR
    IM
    IL
    IT
    JM
    JP
    JE
    JO
    KZ
    KE
    KI
    KP
    KR
    KW
    KG
    LA
    LV
    LB
    LS
    LR
    LY
    LI
    LT
    LU
    MO
    MK
    MG
    MW
    MY
    MV
    ML
    MT
    MH
    MQ
    MR
    MU
    YT
    MX
    FM
    MD
    MC
    MN
    ME
    MS
    MA
    MZ
    MM
    NA
    NR
    NP
    NL
    NC
    NZ
    NI
    NE
    NG
    NU
    NF
    MP
    NO
    OM
    PK
    PW
    PS
    PA
    PG
    PY
    PE
    PH
    PN
    PL
    PT
    PR
    QA
    RE
    RO
    RU
    RW
    BL
    SH
    KN
    LC
    MF
    PM
    VC
    WS
    SM
    ST
    SA
    SN
    RS
    SC
    SL
    SG
    SX
    SK
    SI
    SB
    SO
    ZA
    GS
    SS
    ES
    LK
    SD
    SR
    SJ
    SZ
    SE
    CH
    SY
    TW
    TJ
    TZ
    TH
    TL
    TG
    TK
    TO
    TT
    TN
    TR
    TM
    TC
    TV
    UG
    UA
    AE
    GB
    US
    UM
    UY
    UZ
    VU
    VE
    VN
    VG
    VI
    WF
    EH
    YE
    ZM
    ZW
}
# SIG # Begin signature block
# MIIOBwYJKoZIhvcNAQcCoIIN+DCCDfQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUu+HabGyBilCYl/waZvIRJJ7o
# xZ+gggs9MIIFVTCCBD2gAwIBAgIRAOQ7pk6be99ARw7gugXITCQwDQYJKoZIhvcN
# AQELBQAwfTELMAkGA1UEBhMCR0IxGzAZBgNVBAgTEkdyZWF0ZXIgTWFuY2hlc3Rl
# cjEQMA4GA1UEBxMHU2FsZm9yZDEaMBgGA1UEChMRQ09NT0RPIENBIExpbWl0ZWQx
# IzAhBgNVBAMTGkNPTU9ETyBSU0EgQ29kZSBTaWduaW5nIENBMB4XDTE5MTAwMjAw
# MDAwMFoXDTIxMTAwMTIzNTk1OVowgZwxCzAJBgNVBAYTAlVTMQ4wDAYDVQQRDAU5
# MjY1NjETMBEGA1UECAwKQ2FsaWZvcm5pYTEUMBIGA1UEBwwLQWxpc28gVmllam8x
# FjAUBgNVBAkMDTQgUG9sYXJpcyBXYXkxHDAaBgNVBAoME1F1ZXN0IFNvZnR3YXJl
# IEluYy4xHDAaBgNVBAMME1F1ZXN0IFNvZnR3YXJlIEluYy4wggEiMA0GCSqGSIb3
# DQEBAQUAA4IBDwAwggEKAoIBAQC0QLBHHs0mb9AKSmxaUJ9vjDn5zvnhNZjHt3ud
# +qn8/yX1ddNp/eRflK1NWm6/RfIxjWfHl45rGRR3AlQKjR7CcxZsLBuhm449vlgA
# hIn5TNsFE8U/4V2m5YoVH9ET2TJgPEmUs9TsJwyA1YYWdVoZ4TfPMG7DHlpla1+R
# LKUeztF/UZm+q2qxYbSCaDZEiRaUEJ9TvgXa9eiQZOktAcoN9fuzuJW8HgHT6snH
# 2mzuJjR8JofbMm+APm3Qg3bMgGnlv1/UKu3TdniMwgwK2HZNf6qlhm5jP6s+256l
# 64GojJP4Z6HmWnFbVD0EXH7atY6s7l+Jz//d/6Y0adRGUpxJAgMBAAGjggGuMIIB
# qjAfBgNVHSMEGDAWgBQpkWD/ik366/mmarjP+eZLvUnOEjAdBgNVHQ4EFgQUbP9G
# anzu1CKGvG28iLn2zJdWfjcwDgYDVR0PAQH/BAQDAgeAMAwGA1UdEwEB/wQCMAAw
# EwYDVR0lBAwwCgYIKwYBBQUHAwMwEQYJYIZIAYb4QgEBBAQDAgQQMEAGA1UdIAQ5
# MDcwNQYMKwYBBAGyMQECAQMCMCUwIwYIKwYBBQUHAgEWF2h0dHBzOi8vc2VjdGln
# by5jb20vQ1BTMEMGA1UdHwQ8MDowOKA2oDSGMmh0dHA6Ly9jcmwuY29tb2RvY2Eu
# Y29tL0NPTU9ET1JTQUNvZGVTaWduaW5nQ0EuY3JsMHQGCCsGAQUFBwEBBGgwZjA+
# BggrBgEFBQcwAoYyaHR0cDovL2NydC5jb21vZG9jYS5jb20vQ09NT0RPUlNBQ29k
# ZVNpZ25pbmdDQS5jcnQwJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3NwLmNvbW9kb2Nh
# LmNvbTAlBgNVHREEHjAcgRptaWNoYWVsLmdvcm9jaGl0QHF1ZXN0LmNvbTANBgkq
# hkiG9w0BAQsFAAOCAQEADLM1M9Xa7P0bAl0U8XK+IH1RkQtIrQ9S/prL8oEgzKdZ
# zE9Q+eGUjxth0UeWje1PTRwMrU9Iu0JpiTyGsQf8+sVPm2Asg2eXKs7c+CuhRzfS
# e+HhaoKRGqC/1WNxQDeNwQbtqpLxwLukSnzTDZnCHB2bQGdJiER8+fQ6KwhxKvg8
# wZEWBs52s7U1jFu1mQsOOnXA9G0aFie1xaxN7XPny+6rsrgSeK6CGtTIwLW3VbgS
# bSPRB4IhGFzKxOuBYXLmmrX9m437MwBw9yiIOWoouGbK+Gc+2UcmzcVLvtdSj44B
# J9NcgGlzHH4P5mKDLN+gSroMm0TWOL+bg1y4B6hupDCCBeAwggPIoAMCAQICEC58
# h8wOk0pS/pT9HLfNNK8wDQYJKoZIhvcNAQEMBQAwgYUxCzAJBgNVBAYTAkdCMRsw
# GQYDVQQIExJHcmVhdGVyIE1hbmNoZXN0ZXIxEDAOBgNVBAcTB1NhbGZvcmQxGjAY
# BgNVBAoTEUNPTU9ETyBDQSBMaW1pdGVkMSswKQYDVQQDEyJDT01PRE8gUlNBIENl
# cnRpZmljYXRpb24gQXV0aG9yaXR5MB4XDTEzMDUwOTAwMDAwMFoXDTI4MDUwODIz
# NTk1OVowfTELMAkGA1UEBhMCR0IxGzAZBgNVBAgTEkdyZWF0ZXIgTWFuY2hlc3Rl
# cjEQMA4GA1UEBxMHU2FsZm9yZDEaMBgGA1UEChMRQ09NT0RPIENBIExpbWl0ZWQx
# IzAhBgNVBAMTGkNPTU9ETyBSU0EgQ29kZSBTaWduaW5nIENBMIIBIjANBgkqhkiG
# 9w0BAQEFAAOCAQ8AMIIBCgKCAQEAppiQY3eRNH+K0d3pZzER68we/TEds7liVz+T
# vFvjnx4kMhEna7xRkafPnp4ls1+BqBgPHR4gMA77YXuGCbPj/aJonRwsnb9y4+R1
# oOU1I47Jiu4aDGTH2EKhe7VSA0s6sI4jS0tj4CKUN3vVeZAKFBhRLOb+wRLwHD9h
# YQqMotz2wzCqzSgYdUjBeVoIzbuMVYz31HaQOjNGUHOYXPSFSmsPgN1e1r39qS/A
# JfX5eNeNXxDCRFU8kDwxRstwrgepCuOvwQFvkBoj4l8428YIXUezg0HwLgA3FLkS
# qnmSUs2HD3vYYimkfjC9G7WMcrRI8uPoIfleTGJ5iwIGn3/VCwIDAQABo4IBUTCC
# AU0wHwYDVR0jBBgwFoAUu69+Aj36pvE8hI6t7jiY7NkyMtQwHQYDVR0OBBYEFCmR
# YP+KTfrr+aZquM/55ku9Sc4SMA4GA1UdDwEB/wQEAwIBhjASBgNVHRMBAf8ECDAG
# AQH/AgEAMBMGA1UdJQQMMAoGCCsGAQUFBwMDMBEGA1UdIAQKMAgwBgYEVR0gADBM
# BgNVHR8ERTBDMEGgP6A9hjtodHRwOi8vY3JsLmNvbW9kb2NhLmNvbS9DT01PRE9S
# U0FDZXJ0aWZpY2F0aW9uQXV0aG9yaXR5LmNybDBxBggrBgEFBQcBAQRlMGMwOwYI
# KwYBBQUHMAKGL2h0dHA6Ly9jcnQuY29tb2RvY2EuY29tL0NPTU9ET1JTQUFkZFRy
# dXN0Q0EuY3J0MCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5jb21vZG9jYS5jb20w
# DQYJKoZIhvcNAQEMBQADggIBAAI/AjnD7vjKO4neDG1NsfFOkk+vwjgsBMzFYxGr
# CWOvq6LXAj/MbxnDPdYaCJT/JdipiKcrEBrgm7EHIhpRHDrU4ekJv+YkdK8eexYx
# biPvVFEtUgLidQgFTPG3UeFRAMaH9mzuEER2V2rx31hrIapJ1Hw3Tr3/tnVUQBg2
# V2cRzU8C5P7z2vx1F9vst/dlCSNJH0NXg+p+IHdhyE3yu2VNqPeFRQevemknZZAp
# QIvfezpROYyoH3B5rW1CIKLPDGwDjEzNcweU51qOOgS6oqF8H8tjOhWn1BUbp1JH
# Mqn0v2RH0aofU04yMHPCb7d4gp1c/0a7ayIdiAv4G6o0pvyM9d1/ZYyMMVcx0Dbs
# R6HPy4uo7xwYWMUGd8pLm1GvTAhKeo/io1Lijo7MJuSy2OU4wqjtxoGcNWupWGFK
# Cpe0S0K2VZ2+medwbVn4bSoMfxlgXwyaiGwwrFIJkBYb/yud29AgyonqKH4yjhnf
# e0gzHtdl+K7J+IMUk3Z9ZNCOzr41ff9yMU2fnr0ebC+ojwwGUPuMJ7N2yfTm18M0
# 4oyHIYZh/r9VdOEhdwMKaGy75Mmp5s9ZJet87EUOeWZo6CLNuO+YhU2WETwJitB/
# vCgoE/tqylSNklzNwmWYBp7OSFvUtTeTRkF8B93P+kPvumdh/31J4LswfVyA4+YW
# OUunMYICNDCCAjACAQEwgZIwfTELMAkGA1UEBhMCR0IxGzAZBgNVBAgTEkdyZWF0
# ZXIgTWFuY2hlc3RlcjEQMA4GA1UEBxMHU2FsZm9yZDEaMBgGA1UEChMRQ09NT0RP
# IENBIExpbWl0ZWQxIzAhBgNVBAMTGkNPTU9ETyBSU0EgQ29kZSBTaWduaW5nIENB
# AhEA5DumTpt730BHDuC6BchMJDAJBgUrDgMCGgUAoHgwGAYKKwYBBAGCNwIBDDEK
# MAigAoAAoQKAADAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgorBgEEAYI3
# AgELMQ4wDAYKKwYBBAGCNwIBFTAjBgkqhkiG9w0BCQQxFgQUurNmyrNt/tCapIN8
# wmZh50sAaXswDQYJKoZIhvcNAQEBBQAEggEAYddjSs506yiBRwMDwpmPFbfjTbP7
# uWnxV9GvI+JnwEGbWftEc/uY+D8ANVP3g1WIYBRh+MOsaPOGKbTqTXJATQZ/pASD
# 63nUrNqpIXEMcI3uHjBhd0n6Yb9colXKdXpzt04pUX7JaRKcx+BONVb1R0W/Te9g
# dGRMHFkwFq52+65RmPZIx2EtN604306khab78Eha0uz5uhEFuRJZUVjXViwl0pWy
# yCrOhAetPL76dJmcKjdHJz3hfFiFLc98sCKN3otmzlFtOlOR+v1qUSnhNOT3PGwc
# RFz9K6sfJcwu9Hh6obnj+/Lwb0YgdihyfCGKZRiYbZxk1oH74vtSKNOIdg==
# SIG # End signature block
