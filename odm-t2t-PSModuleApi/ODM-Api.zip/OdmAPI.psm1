﻿### Initialization ###############

. (Join-Path $PSScriptRoot OdmAPI.Types.ps1)
. (Join-Path $PSScriptRoot OdmAPI.CommonFunctions.ps1)
. (Join-Path $PSScriptRoot OdmAPI.ReadFunctions.ps1)
. (Join-Path $PSScriptRoot OdmAPI.WriteFunctions.ps1)

### Internal ###############

[Object]$TokenCache = $null
[Object]$AuthCache = $null
[Object]$Settings = $null

function IIf($If, $Right, $Wrong)
{
    If ($If) {$Right} Else {$Wrong}
}

function GetTokenString
{
	$script:TokenCache.xcloud_token
}

function GetToken
{
	try
    {
        $clientId = $Settings.nativeAppId
        $authBaseUrl = [uri]"$($Settings.authority)"
        $redirect = [uri]$Settings.proxyURL
		$OpenId = $Settings.open_id_auth
		
		$script:ApiUrl = $Settings.api_url
		
		$xcloudApiUrl = $Settings.xcloud_api_url
		$xcloudKey = $Settings.xcloud_key

        $Body = ''
        $Headers = $null
        $session = $null

        if ($script:AuthCache.userName -and $script:AuthCache.password)
		{
			$request = [uri]"$authBaseUrl/$(IIf $OpenId "auth" "oauth2/authorize")?client_id=$clientId&redirect_uri=$redirect&response_type=code"

            $res = Invoke-WebRequest -Method Get -Uri $request -MaximumRedirection 0 -ErrorAction Ignore -SessionVariable session -UseBasicParsing
			$res.Content -match 'kc-form-login.*action="([^"]*)"' | Out-Null
			$request = $Matches[1].Replace('&amp;', '&')

			$res = Invoke-WebRequest $request -ContentType 'application/x-www-form-urlencoded' -Body "username=$($script:AuthCache.userName)&password=$($script:AuthCache.password)" -Method Post -WebSession $session -MaximumRedirection 0 -ErrorAction Ignore -UseBasicParsing
			([Uri]$res.Headers.Location).Query -match 'code=([^&]*)' | Out-Null
			$code = $Matches[1]

			if (-not ($code))
			{
				throw "Code not received."
			}

			$Body = "client_id=$clientId&redirect_uri=$redirect&grant_type=authorization_code&code=$code"
		}
        else
        {
            $currentFolder = Split-Path -Parent $PSCommandPath

            $openIdAssemblymFile = "$($currentFolder)\OpenIdConnectWithBrowser.dll"

            $fileStream = ([System.IO.FileInfo] (Get-Item $openIdAssemblymFile)).OpenRead();
            $assemblyBytes = new-object byte[] $fileStream.Length
            $readBytes = $fileStream.Read($assemblyBytes, 0, $fileStream.Length);
            $fileStream.Close();

            $assembly = [Reflection.Assembly]::Load($assemblyBytes)

            $request = [uri]"$authBaseUrl/$(IIf $OpenId "auth" "oauth2/authorize")?client_id=$clientId&redirect_uri=$redirect&response_type=code"

            $type = $assembly.GetType('OpenIdConnectWithBrowser.OpenIdConnect')
            $instance = [Activator]::CreateInstance($type)

            $code = $type.GetMethod('GetAuthCode', [Reflection.BindingFlags]'Instance,Public').Invoke($instance, ($request, $redirect))

			if ($code -eq $null -or $code -eq '')
			{
				throw "Code not received."
			}

			$Body = "client_id=$clientId&redirect_uri=$redirect&grant_type=authorization_code&code=$code"
        }

		$result = Invoke-RestMethod "$authBaseUrl/$(IIf $OpenId "token" "oauth2/token")" -Method POST -Body $Body -Headers $Headers -WebSession $session

        $script:TokenCache = @{ 
            clientId = $clientId
            authBaseUrl = $authBaseUrl
            openId = $OpenId

            timestamp = Get-Date

            token = $result.access_token
            refresh_token = $result.refresh_token
            session = $session

			xcloudApiUrl = $xcloudApiUrl
			xcloudKey = $xcloudKey

			xcloud_timestamp = $null
			xcloud_token = $null
        }
    }
    catch {throw "Authentication failed. " + $_.Exception.Message}
}

function CheckOrganizationExists($OrganizationId)
{
	try
	{
		if ( $OrganizationId -ne [Guid]::Empty )
		{
			$xcl_token = Invoke-RestMethod -Uri "$($script:TokenCache.xcloudApiUrl)/organizations/$($OrganizationId)/token" -Headers @{ Authorization = "Bearer $($script:TokenCache.token)"; "Ocp-Apim-Subscription-Key" = "$($script:TokenCache.xcloudKey)" } -Method Post

			if ($xcl_token)
			{
				$true
			}
		}
		else
		{
			$false
		}
	}
	catch { $false }
}

function CheckTokenForUpdate
{
	param(
        [Parameter(Mandatory=$false)]
        [switch]$TokenRequested
    )

	try
	{
		if( $script:TokenCache.timestamp -and ( ([TimeSpan]'00:04:30') -lt ( (Get-Date) - $script:TokenCache.timestamp ) ) )
		{

			$Headers = $null
			$Body = "client_id=$($script:TokenCache.clientId)&grant_type=refresh_token&refresh_token=$($script:TokenCache.refresh_token)"

			$result = Invoke-RestMethod "$($script:TokenCache.authBaseUrl)/$(IIf $script:TokenCache.openId "token" "oauth2/token")" -Method POST -Body $Body -Headers $Headers -WebSession $script:TokenCache.session

			$script:TokenCache.timestamp = Get-Date
			$script:TokenCache.token = $result.access_token
            $script:TokenCache.refresh_token = $result.refresh_token
		}

		if( ( $script:TokenCache.xcloud_timestamp -eq $null -and $script:OdmOrganization -ne [Guid]::Empty ) -or ( $script:TokenCache.xcloud_timestamp -ne $null -and ([TimeSpan]'00:04:30') -lt ( (Get-Date) - $script:TokenCache.xcloud_timestamp ) ) )
		{
			$xcl_token = Invoke-RestMethod -Uri "$($script:TokenCache.xcloudApiUrl)/organizations/$($script:OdmOrganization)/token" -Headers @{ Authorization = "Bearer $($script:TokenCache.token)"; "Ocp-Apim-Subscription-Key" = "$($script:TokenCache.xcloudKey)" } -Method Post

			$script:TokenCache.xcloud_token = $xcl_token.token

			$script:TokenCache.xcloud_timestamp = Get-Date
		}
	}
	catch
	{
		if (-not $TokenRequested)
		{
			GetToken

			CheckTokenForUpdate -TokenRequested
		}
		else
		{
			throw
		}
	}
}

### Public ###############

function Connect-OdmService
{
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$false)]
        [string]$Region = 'us',
        [Parameter(Mandatory=$false)]
        [string]$Region2EndpointMapUrl = 'https://odmprodconfiguration.blob.core.windows.net/common/psApiConfiguration.json',
		[Parameter(Mandatory=$false)]
        [string]$UserName = '',
        [Parameter(Mandatory=$false)]
        [string]$Password = ''
    )

    try
    {
        $region2EndpointMap = (Invoke-RestMethod -Uri $region2EndpointMapUrl).psobject.properties | % { $ht = @{} } { $ht[$_.Name] = $_.Value } { $ht }
    }
    catch {throw $MessagesDictionary['ServiceUnavailable'] + " " + $_.Exception.Message}

    $script:Settings = $region2EndpointMap[$Region]

    if (-not $script:Settings)
    {
        throw $($MessagesDictionary['NoSettings'] -f $Region)
    }
    Write-Debug "Acquiring authorization token for clientId '$($Settings.nativeAppId)' to access '$($Settings.proxyURL)'."

	$script:AuthCache = @{ 
		userName = $UserName
		password = $Password
    }

    GetToken
}

### Exported functions

Export-ModuleMember Connect-OdmService,
	Select-OdmOrganization,
    Get-OdmProject,
    Select-OdmProject,
    Get-OdmTask,
    Get-OdmEvent,
    Get-OdmObject,
    Get-OdmCollection,
	Start-OdmTask,
    Stop-OdmTask,
    Add-OdmObject,
    Remove-OdmObject,
    New-OdmCollection,
    Set-OdmCollection,
    Remove-OdmCollection,
    Remove-OdmTask,
    New-OdmMailMigrationTask,
    Set-OdmMailMigrationTask,
    New-OdmMatchingTask,
    Set-OdmMatchingTask,
    New-OdmDiscoveryTask,
    Set-OdmDiscoveryTask,
    New-OdmMailSwitchTask,
    Set-OdmMailSwitchTask,
    New-OdmCalendarSharingTask,
    Set-OdmCalendarSharingTask,
    New-OdmProcessingTask,
    Set-OdmProcessingTask,
    New-OdmDomainCoexistenceTask,
    Set-OdmDomainCoexistenceTask,
    New-OdmMappingFileTask,
    Set-OdmMappingFileTask,
    New-OdmOneDriveMigrationTask,
    Set-OdmOneDriveMigrationTask,
    New-OdmOneDriveStatisticsTask,
    Set-OdmOneDriveStatisticsTask,
    New-OdmMigrationTask,
    Set-OdmMigrationTask,
	New-OdmAddressRewritingTask,
    New-OdmCopyPermissionTask,
	New-OdmCopyPermission-SplitAndProcessTask
# SIG # Begin signature block
# MIIOBwYJKoZIhvcNAQcCoIIN+DCCDfQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQU6C7yZDjSUtk/6355Zp66d3Ia
# NZagggs9MIIFVTCCBD2gAwIBAgIRAOQ7pk6be99ARw7gugXITCQwDQYJKoZIhvcN
# AQELBQAwfTELMAkGA1UEBhMCR0IxGzAZBgNVBAgTEkdyZWF0ZXIgTWFuY2hlc3Rl
# cjEQMA4GA1UEBxMHU2FsZm9yZDEaMBgGA1UEChMRQ09NT0RPIENBIExpbWl0ZWQx
# IzAhBgNVBAMTGkNPTU9ETyBSU0EgQ29kZSBTaWduaW5nIENBMB4XDTE5MTAwMjAw
# MDAwMFoXDTIxMTAwMTIzNTk1OVowgZwxCzAJBgNVBAYTAlVTMQ4wDAYDVQQRDAU5
# MjY1NjETMBEGA1UECAwKQ2FsaWZvcm5pYTEUMBIGA1UEBwwLQWxpc28gVmllam8x
# FjAUBgNVBAkMDTQgUG9sYXJpcyBXYXkxHDAaBgNVBAoME1F1ZXN0IFNvZnR3YXJl
# IEluYy4xHDAaBgNVBAMME1F1ZXN0IFNvZnR3YXJlIEluYy4wggEiMA0GCSqGSIb3
# DQEBAQUAA4IBDwAwggEKAoIBAQC0QLBHHs0mb9AKSmxaUJ9vjDn5zvnhNZjHt3ud
# +qn8/yX1ddNp/eRflK1NWm6/RfIxjWfHl45rGRR3AlQKjR7CcxZsLBuhm449vlgA
# hIn5TNsFE8U/4V2m5YoVH9ET2TJgPEmUs9TsJwyA1YYWdVoZ4TfPMG7DHlpla1+R
# LKUeztF/UZm+q2qxYbSCaDZEiRaUEJ9TvgXa9eiQZOktAcoN9fuzuJW8HgHT6snH
# 2mzuJjR8JofbMm+APm3Qg3bMgGnlv1/UKu3TdniMwgwK2HZNf6qlhm5jP6s+256l
# 64GojJP4Z6HmWnFbVD0EXH7atY6s7l+Jz//d/6Y0adRGUpxJAgMBAAGjggGuMIIB
# qjAfBgNVHSMEGDAWgBQpkWD/ik366/mmarjP+eZLvUnOEjAdBgNVHQ4EFgQUbP9G
# anzu1CKGvG28iLn2zJdWfjcwDgYDVR0PAQH/BAQDAgeAMAwGA1UdEwEB/wQCMAAw
# EwYDVR0lBAwwCgYIKwYBBQUHAwMwEQYJYIZIAYb4QgEBBAQDAgQQMEAGA1UdIAQ5
# MDcwNQYMKwYBBAGyMQECAQMCMCUwIwYIKwYBBQUHAgEWF2h0dHBzOi8vc2VjdGln
# by5jb20vQ1BTMEMGA1UdHwQ8MDowOKA2oDSGMmh0dHA6Ly9jcmwuY29tb2RvY2Eu
# Y29tL0NPTU9ET1JTQUNvZGVTaWduaW5nQ0EuY3JsMHQGCCsGAQUFBwEBBGgwZjA+
# BggrBgEFBQcwAoYyaHR0cDovL2NydC5jb21vZG9jYS5jb20vQ09NT0RPUlNBQ29k
# ZVNpZ25pbmdDQS5jcnQwJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3NwLmNvbW9kb2Nh
# LmNvbTAlBgNVHREEHjAcgRptaWNoYWVsLmdvcm9jaGl0QHF1ZXN0LmNvbTANBgkq
# hkiG9w0BAQsFAAOCAQEADLM1M9Xa7P0bAl0U8XK+IH1RkQtIrQ9S/prL8oEgzKdZ
# zE9Q+eGUjxth0UeWje1PTRwMrU9Iu0JpiTyGsQf8+sVPm2Asg2eXKs7c+CuhRzfS
# e+HhaoKRGqC/1WNxQDeNwQbtqpLxwLukSnzTDZnCHB2bQGdJiER8+fQ6KwhxKvg8
# wZEWBs52s7U1jFu1mQsOOnXA9G0aFie1xaxN7XPny+6rsrgSeK6CGtTIwLW3VbgS
# bSPRB4IhGFzKxOuBYXLmmrX9m437MwBw9yiIOWoouGbK+Gc+2UcmzcVLvtdSj44B
# J9NcgGlzHH4P5mKDLN+gSroMm0TWOL+bg1y4B6hupDCCBeAwggPIoAMCAQICEC58
# h8wOk0pS/pT9HLfNNK8wDQYJKoZIhvcNAQEMBQAwgYUxCzAJBgNVBAYTAkdCMRsw
# GQYDVQQIExJHcmVhdGVyIE1hbmNoZXN0ZXIxEDAOBgNVBAcTB1NhbGZvcmQxGjAY
# BgNVBAoTEUNPTU9ETyBDQSBMaW1pdGVkMSswKQYDVQQDEyJDT01PRE8gUlNBIENl
# cnRpZmljYXRpb24gQXV0aG9yaXR5MB4XDTEzMDUwOTAwMDAwMFoXDTI4MDUwODIz
# NTk1OVowfTELMAkGA1UEBhMCR0IxGzAZBgNVBAgTEkdyZWF0ZXIgTWFuY2hlc3Rl
# cjEQMA4GA1UEBxMHU2FsZm9yZDEaMBgGA1UEChMRQ09NT0RPIENBIExpbWl0ZWQx
# IzAhBgNVBAMTGkNPTU9ETyBSU0EgQ29kZSBTaWduaW5nIENBMIIBIjANBgkqhkiG
# 9w0BAQEFAAOCAQ8AMIIBCgKCAQEAppiQY3eRNH+K0d3pZzER68we/TEds7liVz+T
# vFvjnx4kMhEna7xRkafPnp4ls1+BqBgPHR4gMA77YXuGCbPj/aJonRwsnb9y4+R1
# oOU1I47Jiu4aDGTH2EKhe7VSA0s6sI4jS0tj4CKUN3vVeZAKFBhRLOb+wRLwHD9h
# YQqMotz2wzCqzSgYdUjBeVoIzbuMVYz31HaQOjNGUHOYXPSFSmsPgN1e1r39qS/A
# JfX5eNeNXxDCRFU8kDwxRstwrgepCuOvwQFvkBoj4l8428YIXUezg0HwLgA3FLkS
# qnmSUs2HD3vYYimkfjC9G7WMcrRI8uPoIfleTGJ5iwIGn3/VCwIDAQABo4IBUTCC
# AU0wHwYDVR0jBBgwFoAUu69+Aj36pvE8hI6t7jiY7NkyMtQwHQYDVR0OBBYEFCmR
# YP+KTfrr+aZquM/55ku9Sc4SMA4GA1UdDwEB/wQEAwIBhjASBgNVHRMBAf8ECDAG
# AQH/AgEAMBMGA1UdJQQMMAoGCCsGAQUFBwMDMBEGA1UdIAQKMAgwBgYEVR0gADBM
# BgNVHR8ERTBDMEGgP6A9hjtodHRwOi8vY3JsLmNvbW9kb2NhLmNvbS9DT01PRE9S
# U0FDZXJ0aWZpY2F0aW9uQXV0aG9yaXR5LmNybDBxBggrBgEFBQcBAQRlMGMwOwYI
# KwYBBQUHMAKGL2h0dHA6Ly9jcnQuY29tb2RvY2EuY29tL0NPTU9ET1JTQUFkZFRy
# dXN0Q0EuY3J0MCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5jb21vZG9jYS5jb20w
# DQYJKoZIhvcNAQEMBQADggIBAAI/AjnD7vjKO4neDG1NsfFOkk+vwjgsBMzFYxGr
# CWOvq6LXAj/MbxnDPdYaCJT/JdipiKcrEBrgm7EHIhpRHDrU4ekJv+YkdK8eexYx
# biPvVFEtUgLidQgFTPG3UeFRAMaH9mzuEER2V2rx31hrIapJ1Hw3Tr3/tnVUQBg2
# V2cRzU8C5P7z2vx1F9vst/dlCSNJH0NXg+p+IHdhyE3yu2VNqPeFRQevemknZZAp
# QIvfezpROYyoH3B5rW1CIKLPDGwDjEzNcweU51qOOgS6oqF8H8tjOhWn1BUbp1JH
# Mqn0v2RH0aofU04yMHPCb7d4gp1c/0a7ayIdiAv4G6o0pvyM9d1/ZYyMMVcx0Dbs
# R6HPy4uo7xwYWMUGd8pLm1GvTAhKeo/io1Lijo7MJuSy2OU4wqjtxoGcNWupWGFK
# Cpe0S0K2VZ2+medwbVn4bSoMfxlgXwyaiGwwrFIJkBYb/yud29AgyonqKH4yjhnf
# e0gzHtdl+K7J+IMUk3Z9ZNCOzr41ff9yMU2fnr0ebC+ojwwGUPuMJ7N2yfTm18M0
# 4oyHIYZh/r9VdOEhdwMKaGy75Mmp5s9ZJet87EUOeWZo6CLNuO+YhU2WETwJitB/
# vCgoE/tqylSNklzNwmWYBp7OSFvUtTeTRkF8B93P+kPvumdh/31J4LswfVyA4+YW
# OUunMYICNDCCAjACAQEwgZIwfTELMAkGA1UEBhMCR0IxGzAZBgNVBAgTEkdyZWF0
# ZXIgTWFuY2hlc3RlcjEQMA4GA1UEBxMHU2FsZm9yZDEaMBgGA1UEChMRQ09NT0RP
# IENBIExpbWl0ZWQxIzAhBgNVBAMTGkNPTU9ETyBSU0EgQ29kZSBTaWduaW5nIENB
# AhEA5DumTpt730BHDuC6BchMJDAJBgUrDgMCGgUAoHgwGAYKKwYBBAGCNwIBDDEK
# MAigAoAAoQKAADAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgorBgEEAYI3
# AgELMQ4wDAYKKwYBBAGCNwIBFTAjBgkqhkiG9w0BCQQxFgQUIxzQVAKP9irxc8QU
# wHAdLo+wxBEwDQYJKoZIhvcNAQEBBQAEggEAGXawyJBQI1UiCroCnsJ4kgO8o0aP
# 27kqXPhgL9I1Anln0z+wFEiwTt1DlUV/ibao4zMC+1nZBSJD59LN7AwcHjpjHo6H
# TTNTHManusRai6zXxYWIb+MdVnLVnqY5P54ETV5vKcKQ9vCUypFsoqKWKbczrRG8
# oKby7uBpebpsDe8x8Wr5QeL/kXMgExx48cZfikuPayMqneoxQ68vikl2oDcNcV/P
# levxDVVSI2K5mcS52cL7VqnAMBI3DKuoE2QXVUBbmkBz2ZVg/CHRESzk1jMZ1emK
# cys5op377Swej9CIkeCWtZPmSJvdW1gQmVZqJ+jO+Cmo05ptwurTLoWaGw==
# SIG # End signature block
