﻿### Initialization ###############

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$ErrorActionPreference = "Stop"

### Internal ###############

$QmmpTaskTypeToTaskType = @{
    Matching = [OdmMatchingTask]
    Migration = [OdmMigrationTask]
    Discover = [OdmDiscoveryTask]
    'OneDrive Migration' = [OdmOneDriveMigrationTask]
    'Mail Migration' = [OdmMailMigrationTask]
    'Mailbox Switch' = [OdmMailSwitchTask]
    'Resource Processing' = [OdmProcessingTask]
    'Calendar Sharing' = [OdmCalendarSharingTask]
    'Mapping from File' = [OdmMappingFileTask]
    'Address Rewriting' = [OdmAddressRewritingTask]
}

$MessagesDictionary = @{
    ServiceUnavailable = 'Service is temporarily unavailable.'
	SelectedOdmProjectIsEmpty = 'Try to get list of projects for selected organization. Then select existing project to proceed.'
	ErrorCode = 'HTTP Error code'
	Description = 'Description'
	NoSettings = 'No settings defined for the ''{0}'' region.'
	OrganizationUnavailable = 'Selected organization is unavailable or has no associated projects.'
	SelectOrganization = 'Select the organization to proceed.'
	ProjectUnavailable = 'Selected project is unavailable.'
	EntityNotCreated = 'The {0} did not created.'
	FileNotLoaded = 'The file did not loaded.'
	EntityNotUpdated = 'The {0} did not updated.'
	EntityNotDeleted = 'The {0} did not removed.'
	TaskNotExist = 'The task with specified ID does not exist.'
	TaskNotStarted = 'The task {0} failed to start.'
	TaskStarted = 'The task {0} successfully started.'
	TaskNotStopped = 'The task {0} failed to stop.'
	TaskStopped = 'The task {0} successfully stopped.'
	ObjectsAdded = 'The specified objects successfully added to {0}.'
	ObjectsRemoved = 'The specified objects successfully removed from {0}.'
	ObjectsNotAdded = "Failed to add {0} following object(s) to the {1}:`r`n`t`r`n`t{2}`r`n`t"
	ObjectsNotRemoved = "Failed to remove {0} following object(s) from the {1}:`r`n`t`r`n`t{2}`r`n`t"
	CollectionNotExist = 'The collection with specified ID does not exist.'
	SureToDeleteCollection = 'Are you sure you want to remove collection "{0}"?'
	SureToDeleteAllCollections = 'Are you sure you want to remove all selected collections?'
	SureToDeleteAllTasks = 'Are you sure you want to remove all selected tasks?'
	SureToDeleteTask = 'Are you sure you want to remove task "{0}"?'
	AddObjects = 'Please don''t forget to add objects to the task'
	TaskNotAllowed = 'Creating tasks with specified Action type is not allowed until Address Rewriting Deploy task is completed.'
	TaskAlreadyDone = 'Running tasks with specified Action type is not allowed because opposite Address Rewriting direction already provisioned.'
	SureToDeleteAllObjects = 'Are you sure you want to remove all specified objects from selected project?'
	SureToDeleteObject = 'Are you sure you want to remove object "{0}" from selected project?'
	TaskCannotBeStopped = 'The task {0} cannot be stopped because it is not in Running state.'
	TaskCannotBeStarted = 'The task {0} cannot be started because it is already in Running state.'
	MustSpecifyToRemove = 'Specify a project, collection or task you want to remove the objects from.'
	MustSpecifyToAdd = 'Specify a collection or task you want to add the objects to.'
	EmptyObjectsList = 'No objects was specified.'
	EmptyTasksList = 'No tasks was specified.'
}

[string]$ApiUrl = $null

function CheckProjectIsSet()
{
	if (!$script:OdmCurrentProject)
	{
		throw $MessagesDictionary['SelectedOdmProjectIsEmpty']
	}
}

function IsTransient {
    Param(
        [Parameter(Mandatory=$true)]
        [System.Management.Automation.ErrorRecord] $ErrorRecord
    )

    $resp = $ErrorRecord.Exception.Response
    if ($resp)
    {
        $code = $resp.StatusCode

        if ($code -eq 408 -or # Request Timeout
            $code -eq 429 -or # Too Many Requests
            $code -eq 500 -or # Internal Server Error
            $code -eq 502 -or # Bad Gateway
            $code -eq 503 -or # Service Unavailable
            $code -eq 504 -or # Gateway Timeout
            $code -eq 599     # Network Connect Timeout Error
        ) {
            return $true
        }
    }

    $false
}

function RetryCommand {

    Param(
        [Parameter(Mandatory=$true)]
        [String] $CommandName,

        [Parameter(Mandatory=$false)]
        [hashtable] $CommandArgs = @{},

        [Parameter(Mandatory=$false)]
        [int] $MaxRetries = 1,

        [Parameter(Mandatory=$false)]
        [int] $WaitTimeInSeconds = 3
    )

    $retrycount = 0
    $CommandArgs.ErrorAction='Stop'

    while ($retrycount++ -lt $MaxRetries) {
        try {
            & $CommandName @CommandArgs
            return
        }
        catch [System.Net.WebException] {

            if(!(IsTransient -ErrorRecord $_))
            {
                Write-Debug "Command failed with non-transient error: $_"
                throw
            }

            $seconds = [int][math]::Pow($WaitTimeInSeconds, $retrycount)
            Write-Debug "Command failed with error: $_`nSleep for $seconds seconds and try again."
            Start-Sleep -Seconds $seconds
        }
    }

    & $CommandName @CommandArgs
}

function Invoke-QmmpApi
{
    param(
        [string]$Entity,
        [string]$Method,
        [string]$Body,
        [Parameter(Mandatory=$false)]
        [string]$Id = $null,
        [Parameter(Mandatory=$false)]
        [string]$SubEntity = $null,
        [Parameter(Mandatory=$false)]
        [string]$FilePath = $null
    )

    try
    {
        RetryCommand -CommandName Invoke-QmmpApi-Internal `
        -CommandArgs @{
            Entity= $Entity
            Method= $Method
            Body= $Body
            Id= $id
            SubEntity= $SubEntity
            FilePath= $FilePath
        } -MaxRetries 5
    }
    catch [System.Net.WebException]
    {
        $resp = $_.Exception.Response

        if ($resp -eq $null)
        {
            throw "Service unavailable. " + $_.Exception.Message
        }
        else
        {
            $reqstream = $resp.GetResponseStream()
            $sr = [System.IO.StreamReader]($reqstream)
            $sr.BaseStream.Position = 0
            $errorBody = $sr.ReadToEnd()

            $resp.Close()

            $code = $resp.StatusCode

            if ($code -eq 500)
            {
                $jsonError = $errorBody | ConvertFrom-Json

                throw ($jsonError.message  | ConvertFrom-Json).reason
            }

            if ($code -eq 400)
            {
                $jsonError = $errorBody | ConvertFrom-Json

                throw $jsonError.error_description
            }

            if ($code -eq 409)
            {
                $jsonError = $errorBody | ConvertFrom-Json

                throw $jsonError.message
            }

            throw "$($MessagesDictionary['ErrorCode']): $($code)`r`n$($MessagesDictionary['Description']): $($errorBody)"
        }
    }
    catch {throw $MessagesDictionary['ServiceUnavailable'] + " " + $_.Exception.Message}
}

function Invoke-QmmpApi-Internal
{
    param(
        [string]$Entity,
        [string]$Method,
        [string]$Body,
        [Parameter(Mandatory=$false)]
        [string]$Id = $null,
        [Parameter(Mandatory=$false)]
        [string]$SubEntity = $null,
        [Parameter(Mandatory=$false)]
        [string]$FilePath = $null
    )

    CheckTokenForUpdate

	$headers = @{
		Authorization = "$(GetTokenString)"
	}

	if ($script:OdmOrganization)
	{
		$headers += @{
			"Tenant" = $script:OdmOrganization
		}
	}

    $url = "$($script:ApiUrl)/$Entity"

    if ($Id)
    {
        $url = "$url/$Id"
    }

    if ($SubEntity)
    {
        $url = "$url/$SubEntity"
    }

    if ($FilePath)
    {
        $content = [System.IO.File]::ReadAllText($FilePath)
        $fileName = [System.IO.Path]::GetFileName($FilePath)

        $Body = "--File-Boundary`r`n" `
            + "Content-Disposition: form-data; name=""file""; filename=""$($fileName)""`r`n" `
            + "Content-Type: text/plain`r`n`r`n" `
            + "$($content)`r`n" `
            + "--File-Boundary--"

        Invoke-RestMethod -Uri $url -Method $Method -ContentType "multipart/form-data; boundary=File-Boundary" -Headers $headers -Body $Body
    }
    else
    {
        Invoke-RestMethod -Uri $url -Method $Method -ContentType "application/json;charset=utf-8" -Headers $headers -Body $Body
    }
}
# SIG # Begin signature block
# MIIOBwYJKoZIhvcNAQcCoIIN+DCCDfQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUb88yWeqoIRgUtI+DVhiqfenA
# k9mgggs9MIIFVTCCBD2gAwIBAgIRAOQ7pk6be99ARw7gugXITCQwDQYJKoZIhvcN
# AQELBQAwfTELMAkGA1UEBhMCR0IxGzAZBgNVBAgTEkdyZWF0ZXIgTWFuY2hlc3Rl
# cjEQMA4GA1UEBxMHU2FsZm9yZDEaMBgGA1UEChMRQ09NT0RPIENBIExpbWl0ZWQx
# IzAhBgNVBAMTGkNPTU9ETyBSU0EgQ29kZSBTaWduaW5nIENBMB4XDTE5MTAwMjAw
# MDAwMFoXDTIxMTAwMTIzNTk1OVowgZwxCzAJBgNVBAYTAlVTMQ4wDAYDVQQRDAU5
# MjY1NjETMBEGA1UECAwKQ2FsaWZvcm5pYTEUMBIGA1UEBwwLQWxpc28gVmllam8x
# FjAUBgNVBAkMDTQgUG9sYXJpcyBXYXkxHDAaBgNVBAoME1F1ZXN0IFNvZnR3YXJl
# IEluYy4xHDAaBgNVBAMME1F1ZXN0IFNvZnR3YXJlIEluYy4wggEiMA0GCSqGSIb3
# DQEBAQUAA4IBDwAwggEKAoIBAQC0QLBHHs0mb9AKSmxaUJ9vjDn5zvnhNZjHt3ud
# +qn8/yX1ddNp/eRflK1NWm6/RfIxjWfHl45rGRR3AlQKjR7CcxZsLBuhm449vlgA
# hIn5TNsFE8U/4V2m5YoVH9ET2TJgPEmUs9TsJwyA1YYWdVoZ4TfPMG7DHlpla1+R
# LKUeztF/UZm+q2qxYbSCaDZEiRaUEJ9TvgXa9eiQZOktAcoN9fuzuJW8HgHT6snH
# 2mzuJjR8JofbMm+APm3Qg3bMgGnlv1/UKu3TdniMwgwK2HZNf6qlhm5jP6s+256l
# 64GojJP4Z6HmWnFbVD0EXH7atY6s7l+Jz//d/6Y0adRGUpxJAgMBAAGjggGuMIIB
# qjAfBgNVHSMEGDAWgBQpkWD/ik366/mmarjP+eZLvUnOEjAdBgNVHQ4EFgQUbP9G
# anzu1CKGvG28iLn2zJdWfjcwDgYDVR0PAQH/BAQDAgeAMAwGA1UdEwEB/wQCMAAw
# EwYDVR0lBAwwCgYIKwYBBQUHAwMwEQYJYIZIAYb4QgEBBAQDAgQQMEAGA1UdIAQ5
# MDcwNQYMKwYBBAGyMQECAQMCMCUwIwYIKwYBBQUHAgEWF2h0dHBzOi8vc2VjdGln
# by5jb20vQ1BTMEMGA1UdHwQ8MDowOKA2oDSGMmh0dHA6Ly9jcmwuY29tb2RvY2Eu
# Y29tL0NPTU9ET1JTQUNvZGVTaWduaW5nQ0EuY3JsMHQGCCsGAQUFBwEBBGgwZjA+
# BggrBgEFBQcwAoYyaHR0cDovL2NydC5jb21vZG9jYS5jb20vQ09NT0RPUlNBQ29k
# ZVNpZ25pbmdDQS5jcnQwJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3NwLmNvbW9kb2Nh
# LmNvbTAlBgNVHREEHjAcgRptaWNoYWVsLmdvcm9jaGl0QHF1ZXN0LmNvbTANBgkq
# hkiG9w0BAQsFAAOCAQEADLM1M9Xa7P0bAl0U8XK+IH1RkQtIrQ9S/prL8oEgzKdZ
# zE9Q+eGUjxth0UeWje1PTRwMrU9Iu0JpiTyGsQf8+sVPm2Asg2eXKs7c+CuhRzfS
# e+HhaoKRGqC/1WNxQDeNwQbtqpLxwLukSnzTDZnCHB2bQGdJiER8+fQ6KwhxKvg8
# wZEWBs52s7U1jFu1mQsOOnXA9G0aFie1xaxN7XPny+6rsrgSeK6CGtTIwLW3VbgS
# bSPRB4IhGFzKxOuBYXLmmrX9m437MwBw9yiIOWoouGbK+Gc+2UcmzcVLvtdSj44B
# J9NcgGlzHH4P5mKDLN+gSroMm0TWOL+bg1y4B6hupDCCBeAwggPIoAMCAQICEC58
# h8wOk0pS/pT9HLfNNK8wDQYJKoZIhvcNAQEMBQAwgYUxCzAJBgNVBAYTAkdCMRsw
# GQYDVQQIExJHcmVhdGVyIE1hbmNoZXN0ZXIxEDAOBgNVBAcTB1NhbGZvcmQxGjAY
# BgNVBAoTEUNPTU9ETyBDQSBMaW1pdGVkMSswKQYDVQQDEyJDT01PRE8gUlNBIENl
# cnRpZmljYXRpb24gQXV0aG9yaXR5MB4XDTEzMDUwOTAwMDAwMFoXDTI4MDUwODIz
# NTk1OVowfTELMAkGA1UEBhMCR0IxGzAZBgNVBAgTEkdyZWF0ZXIgTWFuY2hlc3Rl
# cjEQMA4GA1UEBxMHU2FsZm9yZDEaMBgGA1UEChMRQ09NT0RPIENBIExpbWl0ZWQx
# IzAhBgNVBAMTGkNPTU9ETyBSU0EgQ29kZSBTaWduaW5nIENBMIIBIjANBgkqhkiG
# 9w0BAQEFAAOCAQ8AMIIBCgKCAQEAppiQY3eRNH+K0d3pZzER68we/TEds7liVz+T
# vFvjnx4kMhEna7xRkafPnp4ls1+BqBgPHR4gMA77YXuGCbPj/aJonRwsnb9y4+R1
# oOU1I47Jiu4aDGTH2EKhe7VSA0s6sI4jS0tj4CKUN3vVeZAKFBhRLOb+wRLwHD9h
# YQqMotz2wzCqzSgYdUjBeVoIzbuMVYz31HaQOjNGUHOYXPSFSmsPgN1e1r39qS/A
# JfX5eNeNXxDCRFU8kDwxRstwrgepCuOvwQFvkBoj4l8428YIXUezg0HwLgA3FLkS
# qnmSUs2HD3vYYimkfjC9G7WMcrRI8uPoIfleTGJ5iwIGn3/VCwIDAQABo4IBUTCC
# AU0wHwYDVR0jBBgwFoAUu69+Aj36pvE8hI6t7jiY7NkyMtQwHQYDVR0OBBYEFCmR
# YP+KTfrr+aZquM/55ku9Sc4SMA4GA1UdDwEB/wQEAwIBhjASBgNVHRMBAf8ECDAG
# AQH/AgEAMBMGA1UdJQQMMAoGCCsGAQUFBwMDMBEGA1UdIAQKMAgwBgYEVR0gADBM
# BgNVHR8ERTBDMEGgP6A9hjtodHRwOi8vY3JsLmNvbW9kb2NhLmNvbS9DT01PRE9S
# U0FDZXJ0aWZpY2F0aW9uQXV0aG9yaXR5LmNybDBxBggrBgEFBQcBAQRlMGMwOwYI
# KwYBBQUHMAKGL2h0dHA6Ly9jcnQuY29tb2RvY2EuY29tL0NPTU9ET1JTQUFkZFRy
# dXN0Q0EuY3J0MCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5jb21vZG9jYS5jb20w
# DQYJKoZIhvcNAQEMBQADggIBAAI/AjnD7vjKO4neDG1NsfFOkk+vwjgsBMzFYxGr
# CWOvq6LXAj/MbxnDPdYaCJT/JdipiKcrEBrgm7EHIhpRHDrU4ekJv+YkdK8eexYx
# biPvVFEtUgLidQgFTPG3UeFRAMaH9mzuEER2V2rx31hrIapJ1Hw3Tr3/tnVUQBg2
# V2cRzU8C5P7z2vx1F9vst/dlCSNJH0NXg+p+IHdhyE3yu2VNqPeFRQevemknZZAp
# QIvfezpROYyoH3B5rW1CIKLPDGwDjEzNcweU51qOOgS6oqF8H8tjOhWn1BUbp1JH
# Mqn0v2RH0aofU04yMHPCb7d4gp1c/0a7ayIdiAv4G6o0pvyM9d1/ZYyMMVcx0Dbs
# R6HPy4uo7xwYWMUGd8pLm1GvTAhKeo/io1Lijo7MJuSy2OU4wqjtxoGcNWupWGFK
# Cpe0S0K2VZ2+medwbVn4bSoMfxlgXwyaiGwwrFIJkBYb/yud29AgyonqKH4yjhnf
# e0gzHtdl+K7J+IMUk3Z9ZNCOzr41ff9yMU2fnr0ebC+ojwwGUPuMJ7N2yfTm18M0
# 4oyHIYZh/r9VdOEhdwMKaGy75Mmp5s9ZJet87EUOeWZo6CLNuO+YhU2WETwJitB/
# vCgoE/tqylSNklzNwmWYBp7OSFvUtTeTRkF8B93P+kPvumdh/31J4LswfVyA4+YW
# OUunMYICNDCCAjACAQEwgZIwfTELMAkGA1UEBhMCR0IxGzAZBgNVBAgTEkdyZWF0
# ZXIgTWFuY2hlc3RlcjEQMA4GA1UEBxMHU2FsZm9yZDEaMBgGA1UEChMRQ09NT0RP
# IENBIExpbWl0ZWQxIzAhBgNVBAMTGkNPTU9ETyBSU0EgQ29kZSBTaWduaW5nIENB
# AhEA5DumTpt730BHDuC6BchMJDAJBgUrDgMCGgUAoHgwGAYKKwYBBAGCNwIBDDEK
# MAigAoAAoQKAADAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgorBgEEAYI3
# AgELMQ4wDAYKKwYBBAGCNwIBFTAjBgkqhkiG9w0BCQQxFgQUXgxG2Hv/SZfssw5o
# QcVB6hOYhq0wDQYJKoZIhvcNAQEBBQAEggEAiakGRuS2AMBpsWgPy+FE69fBH2f6
# VLrheAxgVaj43hG0oam777MssP2YN4aH/FcrZpUdG5a9jIJX2eUcVRdbUUCS0EXg
# /rhbgf7sObqJvpQ4ubyrjIBIler33FVUNyGnR8c3W7ZMl+2cXd67u18xQQv2wiUH
# AE7dUqGPV1RIPjvxhdxFMNhLO4xiCQGBO2AMVEDxLosyX1uL5cVwgQ9+egYXcCLM
# fY8CTWv36L3MjWSBDWD29rJ+MCAwvUI1jCvQ48Mr0By4XU8BSTbg7rjUCmZP0Ayx
# 2dhJZ4k6wFU/s1wa3r3AO7380AmToGHFywJi1SwwVX6j8Q2LC5kH3jFe5Q==
# SIG # End signature block
