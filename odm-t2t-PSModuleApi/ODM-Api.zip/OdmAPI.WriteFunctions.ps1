﻿### Internal ###############

function GetEnumStringValue
{
    param(
        [Enum]$EnumValue,
        [switch]$StartsInLowerCase,
		[switch]$InLowerCase
    )
    
    if ($EnumValue -eq $null)
    {
        $null
    }
    elseif ($StartsInLowerCase)
    {
        $result = [string]$EnumValue

        "$($result.Substring(0, 1).ToLower())$($result.Substring(1))" 
    }
	elseif ($InLowerCase)
    {
        $result = [string]$EnumValue

        $result.ToLower() 
    }
    else
    {
        [string]$EnumValue
    }
}

function GetNewTaskCommonProperties
{
    param(
        [string]$TaskType,
        [Nullable[DateTime]]$StartTime
    )
    
    $properties = @{
        ProjectId = $script:OdmCurrentProject._Id;
		
        Schedule = $null;
        Type = $TaskType;

        Run = GetEnumStringValue -EnumValue ([RunTaskEnum]::Later) -StartsInLowerCase;

		Status = 'New';
    }

    if ($StartTime -ne $null)
    {
        $properties['Schedule'] = New-Object OdmSchedule -Property @{ StartTime = $StartTime.ToUniversalTime(); Cron = $StartTime.ToUniversalTime().ToString("m H d M ? yyyy"); }

		$properties['Run'] = GetEnumStringValue -EnumValue ([RunTaskEnum]::Schedule) -StartsInLowerCase
    }

    $properties
}

function GetUniversalTime
{
    param(
        [Nullable[DateTime]]$Value
    )
    
    if ($Value)
    {
        $Value.ToUniversalTime()
    }
    else
    {
        $Value
    }
}

function ConfigureScheduling
{
    param(
        [OdmTask]$TaskObj,
        [Nullable[DateTime]]$ScheduledStartTime
    )

    if ($ScheduledStartTime)
    {
        $TaskObj.Schedule = New-Object OdmSchedule -Property @{ StartTime = GetUniversalTime -Value $ScheduledStartTime; Cron = (GetUniversalTime -Value $ScheduledStartTime).ToString("m H d M ? yyyy") };
        $TaskObj.Run = GetEnumStringValue -EnumValue ([RunTaskEnum]::Schedule) -StartsInLowerCase; 
    }
    else
    {
        $TaskObj.Schedule = $null;
        $TaskObj.Run = GetEnumStringValue -EnumValue ([RunTaskEnum]::Later) -StartsInLowerCase;
    }
}

function New-QmmpEntity
{
    param(
        [string]$EntityType,
        [OdmEntity]$Entity,
        [switch]$PassThru
    )
	Try
	{
		$result = Invoke-QmmpApi -Entity $EntityType -Method 'POST' -Body $([Newtonsoft.Json.JsonConvert]::SerializeObject($Entity))
	}
    catch {throw $($($MessagesDictionary['EntityNotCreated'] -f $EntityType.Substring(0, $EntityType.Length - 1)) + " " + $_.Exception.Message)}

	if (-not $result -or $result._shards.successful -eq 0)
	{
		throw $($MessagesDictionary['EntityNotCreated'] -f $EntityType.Substring(0, $EntityType.Length - 1))
	}
	else
	{
		$Entity._Id = $result._id

		if ($PassThru)
		{
			if ($EntityType -eq 'tasks')
			{
				Get-OdmTask -Task $Entity._Id
			}
			elseif ($EntityType -eq 'collections')
			{
				Get-OdmCollection -Collection $Entity._Id
			}
		}
	}
}

function UploadFile
{
    param(
        [string]$FilePath
    )

	Try
	{
		$result = Invoke-QmmpApi -Entity 'files' -Method 'POST' -FilePath $FilePath
	}
	catch {throw $($MessagesDictionary['FileNotLoaded'] + " " + $_.Exception.Message)}

	if (-not $result -or $result._shards.successful -eq 0)
	{
		throw $MessagesDictionary['FileNotLoaded']
	}
	else
	{
		$result._id
	}
}

function GetConfirmation
{
	param(
        [string]$Question
    )

	process
    {
		$choices = New-Object Collections.ObjectModel.Collection[Management.Automation.Host.ChoiceDescription]
		$choices.Add((New-Object Management.Automation.Host.ChoiceDescription -ArgumentList '&Yes'))
		$choices.Add((New-Object Management.Automation.Host.ChoiceDescription -ArgumentList '&No'))

		$decision = $Host.UI.PromptForChoice('Confirmation', $question, $choices, 1)

		$($decision -eq 0)
    } 
}

function StartTask
{
    param(
        [OdmTask]$Task
    )

    process
    {
		$TaskObj = Get-OdmTaskOrThrow -Id $Task._Id

		if ($TaskObj)
		{
			$Body = @{ action = "Start"; lastResultDescription = "Started by user"; progress = 0; status = "In Progress" }

			$result = Invoke-QmmpApi -Entity 'tasks' -Method 'PATCH' -Body $([Newtonsoft.Json.JsonConvert]::SerializeObject($local:Body)) -Id $TaskObj._id

			if ($result._shards.successful -eq 0)
			{
				throw $($MessagesDictionary['TaskNotStarted'] -f $TaskObj._Id)
			}
			else
			{
				Write-Debug $($MessagesDictionary['TaskStarted'] -f $TaskObj._Id)
			}
		}
    } 
}

function Set-QmmpEntity
{
    param(
        [string]$EntityType,
        [OdmEntity]$Entity,
        [switch]$PassThru,
		[switch]$StartTaskIfNow
    )

	Try
	{
		$result = Invoke-QmmpApi -Entity $EntityType -Method 'PATCH' -Body $([Newtonsoft.Json.JsonConvert]::SerializeObject($Entity)) -Id $Entity._Id
	}
    catch {throw $($($MessagesDictionary['EntityNotUpdated'] -f $EntityType.Substring(0, $EntityType.Length - 1)) + " " + $_.Exception.Message)}

	if (-not $result -or $result._shards.successful -eq 0)
	{
		throw $($MessagesDictionary['EntityNotUpdated'] -f $EntityType.Substring(0, $EntityType.Length - 1))
	}
	else
	{
		if ($StartTaskIfNow -and $EntityType -eq 'tasks' -and $Entity.Run -eq [RunTaskEnum]::Now)
		{
			StartTask -Task $Entity
		}

		if ($PassThru)
		{
			if ($EntityType -eq 'tasks')
			{
				Get-OdmTask -Task $Entity._Id
			}
			elseif ($EntityType -eq 'collections')
			{
				Get-OdmCollection -Collection $Entity._Id
			}
		}
	}
}

function Remove-QmmpEntity
{
    param(
        [string]$EntityType,
        [OdmEntity[]]$Entities
    )
    
	Try
	{
		$ids = @()

		foreach ($Entity in @($Entities))
		{
			$ids += $Entity._Id
		}

		if ($EntityType -eq 'tasks')
		{
			$query = @{ query = @{ filtered = @{ filter = @{ and = @( @{ not = @{ term = @{ hidden = $true } } }; @{ not = @{ term = @{ draft = $true } } }; @{ term = @{ projectId = $script:OdmCurrentProject._Id } }; @{ terms = @{ _id = @($ids) } } ) } } } }
		}
		else
		{
			$query = @{ query = @{ filtered = @{ filter = @{ and = @( @{ not = @{ term = @{ draft = $true } } }; @{ term = @{ projectId = $script:OdmCurrentProject._Id } }; @{ terms = @{ _id = @($ids) } } ) } } } }
		}

		$result = Invoke-QmmpApi -Entity $EntityType -Method 'DELETE' -Body $([Newtonsoft.Json.JsonConvert]::SerializeObject($query))
	}
	catch {throw $($($MessagesDictionary['EntityNotDeleted'] -f $EntityType) + " " + $_.Exception.Message)}

	if ($result._shards.failed -gt 0) {throw $($MessagesDictionary['EntityNotDeleted'] -f $EntityType)}
}

function Get-OdmTaskOrThrow
{
    param(
        [string]$Id
    )

    process
    {
        $task = Get-OdmTask -Task $Id

		if (-not $task)
		{
			throw $MessagesDictionary['TaskNotExist']
		}
		else
		{
			$task
		}
    }
}

function CanProvisionAddressRewriting
{
    param (
        [Parameter(Mandatory=$true)]
        [AddressRewritingActionEnum]$Action,
		[Parameter(Mandatory=$true)]
		[AllowNull()]
        [OdmTask[]]$ExistingTasks
    )

    process
    {
		$DeployTask = $ExistingTasks | ? { $_.Action -eq [AddressRewritingActionEnum]::Deploy -and $_.Status -ne 'New' }
		$DeployReverseTask = $ExistingTasks | ? { $_.Action -eq [AddressRewritingActionEnum]::DeployReverse -and $_.Status -ne 'New' }

		$WantDeploy = $Action -eq [AddressRewritingActionEnum]::Deploy
		$WantDeployReverse = $Action -eq [AddressRewritingActionEnum]::DeployReverse

        ($WantDeploy -and $DeployReverseTask) -or ($WantDeployReverse -and $DeployTask)
    }
}

function IsAddressRewritingProvisioned
{
    param (
		[Parameter(Mandatory=$true)]
		[AllowNull()]
        [OdmTask[]]$ExistingTasks,
		[Parameter(Mandatory=$false)]
		[switch]$OrFailed
    )

    process
    {
		$DeployTask = $ExistingTasks | ? { $_.Action -eq [AddressRewritingActionEnum]::Deploy -and ( $_.Status -eq 'Completed' -or ( $OrFailed -and $_.Status -eq 'Failed' ) ) }
		$DeployReverseTask = $ExistingTasks | ? { $_.Action -eq [AddressRewritingActionEnum]::DeployReverse -and ( $_.Status -eq 'Completed' -or ( $OrFailed -and $_.Status -eq 'Failed' ) ) }

		$DeployTask -or $DeployReverseTask
    }
}

### Public ###############

function New-OdmMailMigrationTask
{
    [CmdletBinding()]
    [OutputType([OdmMailMigrationTask])]
    param(
		[Parameter(Mandatory=$false)]
		[ValidateNotNullOrEmpty()]
        [string]$Name = 'Mail Migration Task',
        [Parameter(Mandatory=$false)]
        [switch]$MigrateFromArchive,
		[Parameter(Mandatory=$false)]
        [switch]$MigrateToArchive,
		[Parameter(Mandatory=$false)]
		[switch]$MigrateMail,
		[Parameter(Mandatory=$false)]
		[switch]$MigrateCalendar,
		[Parameter(Mandatory=$false)]
		[switch]$MigrateContacts,
		[Parameter(Mandatory=$false)]
		[switch]$MigrateTasks,
		[Parameter(Mandatory=$false)]
		[switch]$MigrateRules,
		[Parameter(Mandatory=$false)]
		[switch]$MigrateRecoverableItems,
		[Parameter(Mandatory=$false)]
		[switch]$MigrateDelegates,
		[Parameter(Mandatory=$false)]
		[switch]$MigrateFolderPermissions,
		[Parameter(Mandatory=$true)]
		[string]$O365LicenseToAssign,
		[Parameter(Mandatory=$true)]
		[O365LicenseAssignmentTypeEnum]$O365LicenseAssignmentType,
		[Parameter(Mandatory=$false)]
		[Nullable[DateTime]]$MigrateMailFrom = $null,
		[Parameter(Mandatory=$false)]
		[Nullable[DateTime]]$MigrateMailUntil = $null,
		[Parameter(Mandatory=$false)]
		[switch]$ExcludeDeletedItems,
		[Parameter(Mandatory=$false)]
		[switch]$ExcludeJunkEmail,
		[Parameter(Mandatory=$false)]
		[switch]$ExcludeDrafts,
		[Parameter(Mandatory=$false)]
		[switch]$ExcludeConversationHistory,
		[Parameter(Mandatory=$false)]
		[switch]$ExcludeSentItems,
		[Parameter(Mandatory=$false)]
		[switch]$ExcludeInbox,
		[Parameter(Mandatory=$false)]
		[string]$ExcludeMailFolders,
		[Parameter(Mandatory=$false)]
		[switch]$IncludeInbox,
		[Parameter(Mandatory=$false)]
		[switch]$IncludeSentItems,
		[Parameter(Mandatory=$false)]
		[switch]$IncludeDrafts,
		[Parameter(Mandatory=$false)]
		[switch]$IncludeDeletedItems,
		[Parameter(Mandatory=$false)]
		[string]$IncludeMailFolders,
		[Parameter(Mandatory=$false)]
		[bool]$OverrideUsageLocation,
		[Parameter(Mandatory=$false)]
		[UsageLocation]$UsageLocation,
		[Parameter(Mandatory=$false)]
		[Nullable[DateTime]]$ScheduledStartTime = $null,
		[Parameter(Mandatory=$false)]
		[ValidateSet("Ignore","Enable","Disable")]
		[string]$MailForwarding = "Enable",
		[Parameter(Mandatory=$false)]
		[switch]$AllowFolderMapping,
		[Parameter(Mandatory=$false)]
		[string]$InboxMappingFolderName,
		[Parameter(Mandatory=$false)]
		[string]$DeletedMappingFolderName,
		[Parameter(Mandatory=$false)]
		[string]$ArchiveMappingFolderName,
		[Parameter(Mandatory=$false)]
		[string]$SentItemsMappingFolderName
    )

    process
    {
        CheckProjectIsSet

        $properties = GetNewTaskCommonProperties -TaskType 'Mail Migration' -StartTime $ScheduledStartTime

		$properties += @{
			Name = $Name;

			# Values are converted to lowercase because of ODM UI combobox case-sensitivity.
			# Values must be "false" or "true" to display settings correctly in ODM UI.
			MigrateFromArchive = (Get-Culture).TextInfo.ToLower($MigrateFromArchive.ToString());
			MigrateToArchive = (Get-Culture).TextInfo.ToLower($MigrateToArchive.ToString());

			MigrateMail = $MigrateMail;
			MigrateCalendar = $MigrateCalendar;
			MigrateContacts = $MigrateContacts;
			MigrateTasks = $MigrateTasks;
			MigrateRules = $MigrateRules;
			MigrateRecoverableItems = $MigrateRecoverableItems;
			MigrateDelegates = $MigrateDelegates;
			MigrateFolderPermissions = $MigrateFolderPermissions;
			O365LicenseToAssign = $O365LicenseToAssign;
			
			ExcludeDeletedItems = $ExcludeDeletedItems;
			ExcludeJunkEmail = $ExcludeJunkEmail;
			ExcludeDrafts = $ExcludeDrafts;
			ExcludeConversationHistory = $ExcludeConversationHistory;
			ExcludeSentItems = $ExcludeSentItems;
			ExcludeInbox = $ExcludeInbox;
			ExcludeMailFolders = $ExcludeMailFolders;
			IncludeInbox = $IncludeInbox;
			IncludeSentItems = $IncludeSentItems;
			IncludeDrafts = $IncludeDrafts;
			IncludeDeletedItems = $IncludeDeletedItems;
			IncludeMailFolders = $IncludeMailFolders;

			AllowFolderMapping = $AllowFolderMapping;
			InboxMappingFolderName = $InboxMappingFolderName;
			SentItemsMappingFolderName = $SentItemsMappingFolderName;
			DeletedMappingFolderName = $DeletedMappingFolderName;
			ArchiveMappingFolderName = $ArchiveMappingFolderName;

            ForwardingAction = 0;
            TargetForwardingDomain = "";
            SourceForwardingDomain = "";
            ForwardingDirection = 0;
            EnableForwarding = $false;

            O365LicenseAssignmentType = GetEnumStringValue -EnumValue $O365LicenseAssignmentType;

            MigrateMailFrom = GetUniversalTime -Value $MigrateMailFrom;
            MigrateMailUntil = GetUniversalTime -Value $MigrateMailUntil;

            TargetConnectionId = "$($script:OdmCurrentProject._Id)-target";

            OverrideUsageLocation = $OverrideUsageLocation
            UsageLocation = GetEnumStringValue -EnumValue $UsageLocation
		}

        switch ((Get-Culture).TextInfo.ToLower($MailForwarding))
        {
            "ignore" {
                $properties += @{
                    Default_MailForwarding = $false
                    Enable_MailForwarding = "false"
                }
                break
            }
            "enable" {
                $properties += @{
                    Default_MailForwarding = $true
                    Enable_MailForwarding = "true"
                }
                break
            }
            "disable" {
                $properties += @{
                    Default_MailForwarding = $true
                    Enable_MailForwarding = "false"
                }
                break
            }
        }


        # task create
		$Task = [OdmMailMigrationTask] $properties

        New-QmmpEntity -EntityType 'tasks' -Entity $Task -PassThru

		Write-Warning $MessagesDictionary['AddObjects']
    } 

	<#
		.PARAMETER  OverrideUsageLocation
			Overwrite existing target value of UsageLocation.
		.PARAMETER  UsageLocation
			By default the source value for UsageLocation is used. A custom value can be set for target instead.
	#>
}

function Set-OdmMailMigrationTask
{
    [CmdletBinding()]
    [OutputType([OdmMailMigrationTask])]
    param(
        [Parameter(Mandatory=$true, ValueFromPipeline=$true)]
        [OdmTask]$Task,
		[Parameter(Mandatory=$false)]
		[ValidateNotNullOrEmpty()]
        [string]$Name = 'Mail Migration Task',
        [Parameter(Mandatory=$false)]
        [switch]$MigrateFromArchive,
		[Parameter(Mandatory=$false)]
        [switch]$MigrateToArchive,
		[Parameter(Mandatory=$false)]
		[switch]$MigrateMail,
		[Parameter(Mandatory=$false)]
		[switch]$MigrateCalendar,
		[Parameter(Mandatory=$false)]
		[switch]$MigrateContacts,
		[Parameter(Mandatory=$false)]
		[switch]$MigrateTasks,
		[Parameter(Mandatory=$false)]
		[switch]$MigrateRules,
		[Parameter(Mandatory=$false)]
		[switch]$MigrateRecoverableItems,
		[Parameter(Mandatory=$false)]
		[switch]$MigrateDelegates,
		[Parameter(Mandatory=$false)]
		[switch]$MigrateFolderPermissions,
		[Parameter(Mandatory=$false)]
		[string]$O365LicenseToAssign,
		[Parameter(Mandatory=$false)]
		[O365LicenseAssignmentTypeEnum]$O365LicenseAssignmentType,
		[Parameter(Mandatory=$false)]
		[Nullable[DateTime]]$MigrateMailFrom = $null,
		[Parameter(Mandatory=$false)]
		[Nullable[DateTime]]$MigrateMailUntil = $null,
		[Parameter(Mandatory=$false)]
		[switch]$ExcludeDeletedItems,
		[Parameter(Mandatory=$false)]
		[switch]$ExcludeJunkEmail,
		[Parameter(Mandatory=$false)]
		[switch]$ExcludeDrafts,
		[Parameter(Mandatory=$false)]
		[switch]$ExcludeConversationHistory,
		[Parameter(Mandatory=$false)]
		[switch]$ExcludeSentItems,
		[Parameter(Mandatory=$false)]
		[switch]$ExcludeInbox,
		[Parameter(Mandatory=$false)]
		[string]$ExcludeMailFolders,
		[Parameter(Mandatory=$false)]
		[switch]$IncludeInbox,
		[Parameter(Mandatory=$false)]
		[switch]$IncludeSentItems,
		[Parameter(Mandatory=$false)]
		[switch]$IncludeDrafts,
		[Parameter(Mandatory=$false)]
		[switch]$IncludeDeletedItems,
		[Parameter(Mandatory=$false)]
		[string]$IncludeMailFolders,
		[Parameter(Mandatory=$false)]
		[bool]$OverrideUsageLocation,
		[Parameter(Mandatory=$false)]
		[UsageLocation]$UsageLocation,
		[Parameter(Mandatory=$false)]
		[ValidateSet("Ignore","Enable","Disable")]
		[string]$MailForwarding,
		[Parameter(Mandatory=$false)]
		[Nullable[DateTime]]$ScheduledStartTime = $null,
		[Parameter(Mandatory=$false)]
		[switch]$PassThru
    )

    process
    {
        CheckProjectIsSet

		$TaskObj = Get-OdmTaskOrThrow -Id $Task._id

		if ($TaskObj)
		{
			foreach ($parameter in $PsBoundParameters.Keys)
			{
				switch ($parameter)
				{
					"Task" { break }
					"PassThru" { break }

					"ScheduledStartTime" { ConfigureScheduling $TaskObj $ScheduledStartTime; break }

					"O365LicenseAssignmentType" { $TaskObj."$parameter" = GetEnumStringValue -EnumValue $PsBoundParameters[$parameter]; break }

					"MigrateMailUntil" { $TaskObj."$parameter" = GetUniversalTime -Value $MigrateMailUntil; break }
					"MigrateMailFrom" { $TaskObj."$parameter" = GetUniversalTime -Value $MigrateMailFrom; break }

					# Values are converted to lowercase because of ODM UI combobox case-sensitivity.
					# Values must be "false" or "true" to display settings correctly in ODM UI.
					"MigrateFromArchive" { $TaskObj."$parameter" = (Get-Culture).TextInfo.ToLower($PsBoundParameters[$parameter].ToString()); break }
					"MigrateToArchive" { $TaskObj."$parameter" = (Get-Culture).TextInfo.ToLower($PsBoundParameters[$parameter].ToString()); break }

                    "UsageLocation" { $TaskObj."$parameter" = GetEnumStringValue -EnumValue $PsBoundParameters[$parameter]; break }

                    "MailForwarding" {
                        switch ((Get-Culture).TextInfo.ToLower($MailForwarding))
                        {
                            "ignore" {
                                $TaskObj.Default_MailForwarding = $false
                                $TaskObj.Enable_MailForwarding = "false"
                                break
                            }
                            "enable" {
                                $TaskObj.Default_MailForwarding = $true
                                $TaskObj.Enable_MailForwarding = "true"
                                break
                            }
                            "disable" {
                                $TaskObj.Default_MailForwarding = $true
                                $TaskObj.Enable_MailForwarding = "false"
                                break
                            }
                        }
                        break
                    }

					default {
						$TaskObj."$parameter" = $PsBoundParameters[$parameter]
					}
				}
			}

			# task create
			Set-QmmpEntity -EntityType 'tasks' -Entity $TaskObj -PassThru:$PassThru
		}
    }

	<#
		.PARAMETER  OverrideUsageLocation
			Overwrite existing target value of UsageLocation.
		.PARAMETER  UsageLocation
			By default the source value for UsageLocation is used. A custom value can be set for target instead.
	#>
}

function Start-OdmTask
{
    [CmdletBinding()]
	[OutputType([bool])]
    param(
        [Parameter(Mandatory=$true, ValueFromPipeline=$true)]
        [OdmTask[]]$Tasks
    )

    begin {
        $ProcessTasksArray = @()
    }
    
	process {
        if ($Tasks)
        {
            $ProcessTasksArray += @($Tasks)
        }
    }

    end
    {
		if (-not $ProcessTasksArray)
		{
			Write-Warning $MessagesDictionary['EmptyTasksList']

			return
		}

        foreach ($Task in $ProcessTasksArray)
        {
			StartTask -Task $Task
        }
    } 
}

function Stop-OdmTask
{
    [CmdletBinding()]
	[OutputType([bool])]
    param(
        [Parameter(Mandatory=$true, ValueFromPipeline=$true)]
        [OdmTask[]]$Tasks
    )

    begin {
        $ProcessTasksArray = @()
    }
    
	process {
        if ($Tasks)
        {
            $ProcessTasksArray += @($Tasks)
        }
    }

    end
    {
		if (-not $ProcessTasksArray)
		{
			Write-Warning $MessagesDictionary['EmptyTasksList']

			return
		}

        $Body = @{ "action" = "Stop" }

        foreach ($Task in $ProcessTasksArray)
        {
			$TaskObj = Get-OdmTaskOrThrow -Id $Task._Id

			if ($TaskObj)
			{
				if ($TaskObj.Status -ne 'In Progress' -and $TaskObj.Status -ne 'Starting')
				{
					throw $($MessagesDictionary['TaskCannotBeStopped'] -f $TaskObj._Id)
				}
				else
				{
					$result = Invoke-QmmpApi -Entity 'tasks' -Method 'PATCH' -Body $([Newtonsoft.Json.JsonConvert]::SerializeObject($local:Body)) -Id $TaskObj._id

					if ($result._shards.successful -eq 0)
					{
						throw $($MessagesDictionary['TaskNotStopped'] -f $TaskObj._Id)
					}
					else
					{
						Write-Debug $($MessagesDictionary['TaskStopped'] -f $TaskObj._Id)
					}
				}
			}
        }
    } 
}

function Add-OdmObject
{
    [CmdletBinding(DefaultParametersetName="FromBoth")]
    [OutputType([OdmObject[]])]
    param(
		[Parameter(Mandatory=$true, ValueFromPipeline=$false, ParameterSetName="FromBoth")]
		[Parameter(Mandatory=$true, ValueFromPipeline=$false, ParameterSetName="FromObjects")]
		[Parameter(Mandatory=$true, ValueFromPipeline=$true, ParameterSetName="FromEntity")]
        [OdmEntity]$To,
		[Parameter(Mandatory=$true, ValueFromPipeline=$false, ParameterSetName="FromBoth")]
		[Parameter(Mandatory=$true, ValueFromPipeline=$true, ParameterSetName="FromObjects")]
		[Parameter(Mandatory=$true, ValueFromPipeline=$false, ParameterSetName="FromEntity")]
		[AllowNull()]
        [OdmObject[]]$Objects,
        [Parameter(Mandatory=$false)]
		[switch]$PassThru
    )
	
	begin {
        $ProcessObjectsArray = @()
    }
    
	process {
        if ($Objects)
        {
            $ProcessObjectsArray += @($Objects)
        }
    }

    end
    {
		if (-not $ProcessObjectsArray)
        {
			Write-Warning $MessagesDictionary['EmptyObjectsList']

            return
        }

		if (-not $To -or -not ($To -is [OdmCollection] -or $To -is [OdmTask]))
		{
			throw $MessagesDictionary['MustSpecifyToAdd']
		}
		else
		{
			CheckProjectIsSet

			if ($To -is [OdmTask])
			{
				$Task = Get-OdmTaskOrThrow -Id $To._Id

				if ($Task)
				{
					switch ($Task.Type)
					{
						"Address Rewriting" { if ($Task.Action -eq [AddressRewritingActionEnum]::AddUsers -or $Task.Action -eq [AddressRewritingActionEnum]::RemoveUsers) { $statusKey = "addressRewriteStatus" }; break }
						"Mail Migration" { $statusKey = "odmeStatus"; break }
						"Mailbox Switch" { $statusKey = "switchStatus"; break }
						"OneDrive Migration" { $statusKey = "oneDriveStatus"; break }
					}

					$RequestDictionary = @{ EntityType = 'tasks'; Id = $Task._Id; UsedEntity = 'task'; BodyKey = 'includedObjects'; }
				}
			}
			elseif ($To -is [OdmCollection])
			{
				$RequestDictionary = @{ EntityType = 'collections'; Id = $To._Id; UsedEntity = 'collection'; BodyKey = 'objects'; }
			}
		
			if ($RequestDictionary)
			{
				$oneTimeCount = 1000
				for ($i = 0; $i -lt $ProcessObjectsArray.Length; $i += $oneTimeCount)
				{
					$ObjectsToProcessAtOneTime = $ProcessObjectsArray | Select -Skip $i -First $oneTimeCount

					$array = @( )

					foreach ($o in $ObjectsToProcessAtOneTime)
					{
						$array += $o._Id
					}

					$Body = @{ 
						"$($RequestDictionary.BodyKey)" = $array;
					}

					if ($statusKey)
					{
						$Body += @{ "initWith" = @{ "$statusKey" = "New" } }
					}

					$result = Invoke-QmmpApi -Entity $RequestDictionary.EntityType -SubEntity 'objects' -Method 'POST' -Body $([Newtonsoft.Json.JsonConvert]::SerializeObject($local:Body)) -Id $RequestDictionary.Id

					if ($result.errors -eq $true)
					{
						$FailedObjects += $result.items | Where-Object { $_.update.status -ne 200 }
					}
				}

				if ($FailedObjects)
				{
					$IdList = @()
				
					foreach ($FailedObject in $FailedObjects)
					{
						$IdList += @( $FailedObject.update._id )
					}

					throw $($MessagesDictionary['ObjectsNotAdded'] -f $FailedObjects.Count, $RequestDictionary.UsedEntity, ($IdList -join "`r`n`t"))
				}

				Write-Debug $($MessagesDictionary['ObjectsAdded'] -f $RequestDictionary.UsedEntity)
			}

			if ($PassThru)
			{
				$ProcessObjectsArray
			}
		}
    }
}

function Remove-OdmObject
{
    [CmdletBinding(DefaultParametersetName="FromBoth")]
    [OutputType([OdmObject[]])]
    param(
		[Parameter(Mandatory=$false, ValueFromPipeline=$false, ParameterSetName="FromBoth")]
		[Parameter(Mandatory=$false, ValueFromPipeline=$false, ParameterSetName="FromObjects")]
		[Parameter(Mandatory=$true, ValueFromPipeline=$true, ParameterSetName="FromEntity")]
        [OdmEntity]$From,
		[Parameter(Mandatory=$true, ValueFromPipeline=$false, ParameterSetName="FromBoth")]
		[Parameter(Mandatory=$true, ValueFromPipeline=$true, ParameterSetName="FromObjects")]
		[Parameter(Mandatory=$true, ValueFromPipeline=$false, ParameterSetName="FromEntity")]
		[AllowNull()]
        [OdmObject[]]$Objects,
        [Parameter(Mandatory=$false)]
		[switch]$PassThru,
		[Parameter(Mandatory=$false)]
		[switch]$Confirm = $true
    )

    begin {
        $ProcessObjectsArray = @()
    }
    
	process {
        if ($Objects)
        {
            $ProcessObjectsArray += @($Objects)
        }
    }

    end
    {
		if (-not $ProcessObjectsArray)
        {
			Write-Warning $MessagesDictionary['EmptyObjectsList']

            return
        }

		if (-not $From)
		{
			$From = $script:OdmCurrentProject
		}

		if (-not ($From -is [OdmCollection] -or $From -is [OdmTask] -or $From -is [OdmProject]))
		{
			throw $MessagesDictionary['MustSpecifyToRemove']
		}
		else
		{
			CheckProjectIsSet

			if ($From -is [OdmProject])
			{
				$question = if (@($ProcessObjectsArray).Count -eq 1) { $MessagesDictionary['SureToDeleteObject'] -f $(@($ProcessObjectsArray)[0]).Name } else { $MessagesDictionary['SureToDeleteAllObjects'] }

				if (-not $Confirm -or (GetConfirmation -Question $question))
				{
					Remove-QmmpEntity -EntityType 'objects' -Entities $ProcessObjectsArray
				}
			}
			else
			{
				if ($From -is [OdmTask])
				{
					$Task = Get-OdmTaskOrThrow -Id $From._Id

					if ($Task)
					{
						$RequestDictionary = @{ EntityType = 'tasks'; Id = $Task._Id; UsedEntity = 'task'; BodyKey = 'includedObjects'; }
					}
				}
				elseif ($From -is [OdmCollection])
				{
					$RequestDictionary = @{ EntityType = 'collections'; Id = $From._Id; UsedEntity = 'collection'; BodyKey = 'objects'; }
				}
		
				if ($RequestDictionary)
				{
					$oneTimeCount = 1000
					for ($i = 0; $i -lt $ProcessObjectsArray.Length; $i += $oneTimeCount)
					{
						$array = @( )

						$ObjectsToProcessAtOneTime = $ProcessObjectsArray | Select -Skip $i -First $oneTimeCount

						foreach ($o in $ObjectsToProcessAtOneTime)
						{
							$array += $o._Id
						}

						$Body = @{ 
							"$($RequestDictionary.BodyKey)" = $array
						}

						$result = Invoke-QmmpApi -Entity $RequestDictionary.EntityType -SubEntity 'objects' -Method 'DELETE' -Body $([Newtonsoft.Json.JsonConvert]::SerializeObject($local:Body)) -Id $RequestDictionary.Id

						if ($result.errors -eq $true)
						{
							$FailedObjects += $result.items | Where-Object { $_.update.status -ne 200 }
						}
					}

					if ($FailedObjects)
					{
						$IdList = @()
				
						foreach ($FailedObject in $FailedObjects)
						{
							$IdList += @( $FailedObject.update._id )
						}

						throw $($MessagesDictionary['ObjectsNotRemoved'] -f $FailedObjects.Count, $RequestDictionary.UsedEntity, ($IdList -join "`r`n`t"))
					}

					Write-Debug $($MessagesDictionary['ObjectsRemoved'] -f $RequestDictionary.UsedEntity)
				}
			}

			if ($PassThru)
			{
				$ProcessObjectsArray
			}
		}
    } 
}

function New-OdmCollection
{
    [CmdletBinding()]
    [OutputType([OdmCollection])]
    param(
        [Parameter(Mandatory=$true)]
		[ValidateNotNullOrEmpty()]
        [string]$Name
    )

    process
    {
        CheckProjectIsSet

        $properties = @{
            Name = $Name
			ProjectId = $script:OdmCurrentProject._Id
        }

		$collection = New-Object OdmCollection -Property $properties

        New-QmmpEntity -EntityType 'collections' -Entity $Collection -PassThru
    }
}

function Set-OdmCollection
{
    [CmdletBinding()]
    [OutputType([OdmCollection])]
    param(
        [Parameter(Mandatory=$true, ValueFromPipeline=$true)]
        [OdmCollection]$Collection,
        [Parameter(Mandatory=$false)]
		[ValidateNotNullOrEmpty()]
        [string]$Name,
        [Parameter(Mandatory=$false)]
		[switch]$PassThru
    )

    process
    {
        CheckProjectIsSet

		$collection = Get-OdmCollection -Collection $Collection._id

		if (-not ($collection))
		{
			throw $MessagesDictionary['CollectionNotExist']
		}
		else
		{
			if ($Name) { $collection.Name = $Name }

			Set-QmmpEntity -EntityType 'collections' -Entity $collection -PassThru:$PassThru
		}
    }
}

function Remove-OdmCollection
{
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true, ValueFromPipeline=$true)]
        [OdmCollection[]]$Collections,
		[Parameter(Mandatory=$false)]
		[switch]$Confirm = $true
    )

	begin {
        $ProcessCollectionsArray = @()
    }
    
	process {
        if ($Collections)
        {
            $ProcessCollectionsArray += @($Collections)
        }
    }

    end
    {
		if (-not $ProcessCollectionsArray)
		{
			return
		}

		$question = if (@($ProcessCollectionsArray).Count -eq 1) { $MessagesDictionary['SureToDeleteCollection'] -f $(if($ProcessCollectionsArray.Name) {$ProcessCollectionsArray.Name} else {$ProcessCollectionsArray._Id} ) } else { $MessagesDictionary['SureToDeleteAllCollections'] }

		if (-not $Confirm -or (GetConfirmation -Question $question))
		{
			Remove-QmmpEntity -EntityType 'collections' -Entities $ProcessCollectionsArray
		}
    } 
}

function Remove-OdmTask
{
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true, ValueFromPipeline=$true)]
        [OdmTask[]]$Tasks,
		[Parameter(Mandatory=$false)]
		[switch]$Confirm = $true
    )

    begin {
        $ProcessTasksArray = @()
    }
    
	process {
        if ($Tasks)
        {
            $ProcessTasksArray += @($Tasks)
        }
    }

    end
    {
		if (-not $ProcessTasksArray)
		{
			return
		}

		$question = if (@($ProcessTasksArray).Count -eq 1) { $MessagesDictionary['SureToDeleteTask'] -f $(if($ProcessTasksArray.Name) {$ProcessTasksArray.Name} else {$ProcessTasksArray._Id}) } else { $MessagesDictionary['SureToDeleteAllTasks'] }

		if (-not $Confirm -or (GetConfirmation -Question $question))
		{
			Remove-QmmpEntity -EntityType 'tasks' -Entities $ProcessTasksArray
		}
    }
}

function New-OdmMatchingTask
{
    [CmdletBinding()]
    [OutputType([OdmMatchingTask])]
    param(
		[Parameter(Mandatory=$false)]
		[ValidateNotNullOrEmpty()]
        [string]$Name = 'Matching Task',
        [Parameter(Mandatory=$true)]
		[MatchingActionEnum]$MatchingAction,
        [Parameter(Mandatory=$false)]
		[MatchingAttributeEnum]$SourceAttribute = [MatchingAttributeEnum]::DisplayName,
        [Parameter(Mandatory=$false)]
		[MatchingAttributeEnum]$TargetAttribute = [MatchingAttributeEnum]::DisplayName,
		[Parameter(Mandatory=$false)]
		[Nullable[DateTime]]$ScheduledStartTime = $null
    )

    process
    {
        CheckProjectIsSet

        $properties = GetNewTaskCommonProperties -TaskType 'Matching' -StartTime $ScheduledStartTime

        $properties += @{
			Name = $Name;

            SourceAttribute = GetEnumStringValue -EnumValue $SourceAttribute -StartsInLowerCase;
            TargetAttribute = GetEnumStringValue -EnumValue $TargetAttribute -StartsInLowerCase;
            MatchingAction = GetEnumStringValue -EnumValue $MatchingAction -InLowerCase;

            TargetConnectionId = "$($script:OdmCurrentProject._Id)-target";
        }

        # task create
		$Task = [OdmMatchingTask] $properties

        New-QmmpEntity -EntityType 'tasks' -Entity $Task -PassThru

		Write-Warning $MessagesDictionary['AddObjects']
    } 
}

function Set-OdmMatchingTask
{
    [CmdletBinding()]
    [OutputType([OdmMatchingTask])]
    param(
        [Parameter(Mandatory=$true, ValueFromPipeline=$true)]
        [OdmTask]$Task,
		[Parameter(Mandatory=$false)]
		[ValidateNotNullOrEmpty()]
        [string]$Name = 'Matching Task',
        [Parameter(Mandatory=$false)]
		[MatchingActionEnum]$MatchingAction,
        [Parameter(Mandatory=$false)]
		[MatchingAttributeEnum]$SourceAttribute,
        [Parameter(Mandatory=$false)]
		[MatchingAttributeEnum]$TargetAttribute,
		[Parameter(Mandatory=$false)]
		[Nullable[DateTime]]$ScheduledStartTime = $null,
		[Parameter(Mandatory=$false)]
		[switch]$PassThru
    )

    process
    {
        CheckProjectIsSet

		$TaskObj = Get-OdmTaskOrThrow -Id $Task._id

		if ($TaskObj)
		{
			foreach ($parameter in $PsBoundParameters.Keys)
			{
				switch ($parameter)
				{
					"Task" { break }
					"PassThru" { break }

					"ScheduledStartTime" { ConfigureScheduling $TaskObj $ScheduledStartTime; break }

					"SourceAttribute" { $TaskObj."$parameter" = GetEnumStringValue -EnumValue $PsBoundParameters[$parameter] -StartsInLowerCase; break }
					"TargetAttribute" { $TaskObj."$parameter" = GetEnumStringValue -EnumValue $PsBoundParameters[$parameter] -StartsInLowerCase; break }
					"MatchingAction" { $TaskObj."$parameter" = GetEnumStringValue -EnumValue $PsBoundParameters[$parameter] -InLowerCase; break }

					default {
						$TaskObj."$parameter" = $PsBoundParameters[$parameter]
					}
				}
			}

			# task create
			Set-QmmpEntity -EntityType 'tasks' -Entity $TaskObj -PassThru:$PassThru
		}
    } 
}

function New-OdmMigrationTask
{
    [CmdletBinding()]
    [OutputType([OdmMigrationTask])]
    param(
		[Parameter(Mandatory=$false)]
		[ValidateNotNullOrEmpty()]
        [string]$Name = 'Migration Task',
        [Parameter(Mandatory=$false)]
		[string]$TargetUpnSuffix,
		[Parameter(DontShow, Mandatory=$false)]
		[string]$TargetOnPremisesOU,
		[Parameter(Mandatory=$false)]
		[Nullable[DateTime]]$ScheduledStartTime = $null
    )

    process
    {
        CheckProjectIsSet

        $properties = GetNewTaskCommonProperties -TaskType 'Migration' -StartTime $ScheduledStartTime

		$properties += @{
			Name = $Name;

            TargetUpnSuffix = if ($TargetUpnSuffix) { $TargetUpnSuffix } else { $script:OdmCurrentProject.TargetTenantDefaultDomainName };

            TargetOnPremisesOU = if ($TargetOnPremisesOU) { $TargetOnPremisesOU } else { "CN=Users" };

			TargetConnectionId = "$($script:OdmCurrentProject._Id)-target";
		}

        # task create
		$Task = [OdmMigrationTask] $properties

        New-QmmpEntity -EntityType 'tasks' -Entity $Task -PassThru

		Write-Warning $MessagesDictionary['AddObjects']
    } 
}

function Set-OdmMigrationTask
{
    [CmdletBinding()]
    [OutputType([OdmMigrationTask])]
    param(
        [Parameter(Mandatory=$true, ValueFromPipeline=$true)]
        [OdmTask]$Task,
		[Parameter(Mandatory=$false)]
		[ValidateNotNullOrEmpty()]
        [string]$Name = 'Migration Task',
        [Parameter(Mandatory=$false)]
		[string]$TargetUpnSuffix,
		[Parameter(DontShow, Mandatory=$false)]
		[string]$TargetOnPremisesOU,
		[Parameter(Mandatory=$false)]
		[Nullable[DateTime]]$ScheduledStartTime = $null,
		[Parameter(Mandatory=$false)]
		[switch]$PassThru
    )

    process
    {
        CheckProjectIsSet

        $TaskObj = Get-OdmTaskOrThrow -Id $Task._id

		if ($TaskObj)
		{
			foreach ($parameter in $PsBoundParameters.Keys)
			{
				switch ($parameter)
				{
					"Task" { break }
					"PassThru" { break }

					"ScheduledStartTime" { ConfigureScheduling $TaskObj $ScheduledStartTime; break }

					default {
						$TaskObj."$parameter" = $PsBoundParameters[$parameter]
					}
				}
			}

			# task create
			Set-QmmpEntity -EntityType 'tasks' -Entity $TaskObj -PassThru:$PassThru
		}
    } 
}

function New-OdmDiscoveryTask
{
    [CmdletBinding()]
    [OutputType([OdmDiscoveryTask])]
    param(
		[Parameter(Mandatory=$false)]
		[ValidateNotNullOrEmpty()]
        [string]$Name = 'Discover Task',
        [Parameter(Mandatory=$false)]
		[switch]$IncludeMailboxDetails,
		[Parameter(Mandatory=$false)]
		[switch]$DiscoverUsingCSV,
		[Parameter(Mandatory=$false)]
		[string]$FilePath = $null,
		[Parameter(Mandatory=$false)]
		[Nullable[DateTime]]$ScheduledStartTime = $null
    )

    process
    {
        CheckProjectIsSet

		if ($DiscoverUsingCSV) 
		{
			$fileId = UploadFile -FilePath $FilePath
			$fileName = [System.IO.Path]::GetFileName($FilePath)
		}

        $properties = GetNewTaskCommonProperties -TaskType 'Discover' -StartTime $ScheduledStartTime

        $properties += @{
			Name = $Name;

            IncludeMailboxDetails = $IncludeMailboxDetails;

			DiscoverUsingCSV = ([string]$DiscoverUsingCSV).ToLower();
			DiscoverMatchingFile = @{ 
										filename = if ($fileName) { $filename } else { $null }; 
										id = if ($fileId) { $fileId } else { $null }; 
										url = if ($fileId) { "/api/files/$fileId/download" } else { $null }; 
									}

            SourceConnectionId = "$($script:OdmCurrentProject._Id)-source";
            TargetConnectionId = "$($script:OdmCurrentProject._Id)-target";
		}

        # task create
		$Task = [OdmDiscoveryTask] $properties

        New-QmmpEntity -EntityType 'tasks' -Entity $Task -PassThru
    } 
}

function Set-OdmDiscoveryTask
{
    [CmdletBinding()]
    [OutputType([OdmDiscoveryTask])]
    param(
        [Parameter(Mandatory=$true, ValueFromPipeline=$true)]
        [OdmTask]$Task,
		[Parameter(Mandatory=$false)]
		[ValidateNotNullOrEmpty()]
        [string]$Name = 'Discover Task',
        [Parameter(Mandatory=$false)]
		[switch]$IncludeMailboxDetails,
		[Parameter(Mandatory=$false)]
		[Nullable[DateTime]]$ScheduledStartTime = $null,
		[Parameter(Mandatory=$false)]
		[switch]$PassThru
    )

    process
    {
        CheckProjectIsSet

        $TaskObj = Get-OdmTaskOrThrow -Id $Task._id

		if ($TaskObj)
		{
			foreach ($parameter in $PsBoundParameters.Keys)
			{
				switch ($parameter)
				{
					"Task" { break }
					"PassThru" { break }

					"ScheduledStartTime" { ConfigureScheduling $TaskObj $ScheduledStartTime; break }

					default {
						$TaskObj."$parameter" = $PsBoundParameters[$parameter]
					}
				}
			}

			$TaskObj.DiscoverUsingCSV = "false";
			$TaskObj.DiscoverMatchingFile = @{ filename = $null; id = $null; url = $null; }

			# task create
			Set-QmmpEntity -EntityType 'tasks' -Entity $TaskObj -PassThru:$PassThru
		}
    } 
}

function New-OdmMailSwitchTask
{
    [CmdletBinding()]
    [OutputType([OdmMailSwitchTask])]
    param(
		[Parameter(Mandatory=$false)]
		[ValidateNotNullOrEmpty()]
        [string]$Name = 'Mailbox Switch Task',
        [Parameter(Mandatory=$true)]
		[SwitchDirectionEnum]$SwitchDirection,
        [Parameter(Mandatory=$false)]
		[string]$ForwardingDomain,
		[Parameter(Mandatory=$false)]
		[switch]$NotifyOrigin,
		[Parameter(Mandatory=$false)]
		[string]$OriginNotificationFromEmail,
		[Parameter(Mandatory=$false)]
		[string]$OriginNotificationFromDisplayName,
		[Parameter(Mandatory=$false)]
		[string]$OriginNotificationSubject,
		[Parameter(Mandatory=$false)]
		[string]$OriginNotificationMessage,
		[Parameter(Mandatory=$false)]
		[switch]$NotifyDestination,
		[Parameter(Mandatory=$false)]
		[string]$DestinationNotificationFromEmail,
		[Parameter(Mandatory=$false)]
		[string]$DestinationNotificationFromDisplayName,
		[Parameter(Mandatory=$false)]
		[string]$DestinationNotificationSubject,
		[Parameter(Mandatory=$false)]
		[string]$DestinationNotificationMessage,
		[Parameter(Mandatory=$false)]
		[Nullable[DateTime]]$ScheduledStartTime = $null
    )

    process
    {
        CheckProjectIsSet

        $properties = GetNewTaskCommonProperties -TaskType 'Mailbox Switch' -StartTime $ScheduledStartTime

		$properties += @{
			Name = $Name;

            ForwardingDomain = $ForwardingDomain;

            SwitchDirection = GetEnumStringValue -EnumValue $SwitchDirection;

			NotifyOrigin = $NotifyOrigin;
			OriginNotificationFromEmail = $OriginNotificationFromEmail;
			OriginNotificationFromDisplayName = $OriginNotificationFromDisplayName;
			OriginNotificationSubject = $OriginNotificationSubject;
			OriginNotificationMessage = $OriginNotificationMessage;

			NotifyDestination = $NotifyDestination;
			DestinationNotificationFromEmail = $DestinationNotificationFromEmail;
			DestinationNotificationFromDisplayName = $DestinationNotificationFromDisplayName;
			DestinationNotificationSubject = $DestinationNotificationSubject;
			DestinationNotificationMessage = $DestinationNotificationMessage;

			TargetConnectionId = "$($script:OdmCurrentProject._Id)-target";
		}

        # task create
		$Task = [OdmMailSwitchTask] $properties

        New-QmmpEntity -EntityType 'tasks' -Entity $Task -PassThru

		Write-Warning $MessagesDictionary['AddObjects']
    } 
}

function Set-OdmMailSwitchTask
{
    [CmdletBinding()]
    [OutputType([OdmMailSwitchTask])]
    param(
        [Parameter(Mandatory=$true, ValueFromPipeline=$true)]
        [OdmTask]$Task,
		[Parameter(Mandatory=$false)]
		[ValidateNotNullOrEmpty()]
        [string]$Name = 'Mailbox Switch Task',
        [Parameter(Mandatory=$false)]
		[SwitchDirectionEnum]$SwitchDirection,
        [Parameter(Mandatory=$false)]
		[string]$ForwardingDomain,
		[Parameter(Mandatory=$false)]
		[switch]$NotifyOrigin,
		[Parameter(Mandatory=$false)]
		[string]$OriginNotificationFromEmail,
		[Parameter(Mandatory=$false)]
		[string]$OriginNotificationFromDisplayName,
		[Parameter(Mandatory=$false)]
		[string]$OriginNotificationSubject,
		[Parameter(Mandatory=$false)]
		[string]$OriginNotificationMessage,
		[Parameter(Mandatory=$false)]
		[switch]$NotifyDestination,
		[Parameter(Mandatory=$false)]
		[string]$DestinationNotificationFromEmail,
		[Parameter(Mandatory=$false)]
		[string]$DestinationNotificationFromDisplayName,
		[Parameter(Mandatory=$false)]
		[string]$DestinationNotificationSubject,
		[Parameter(Mandatory=$false)]
		[string]$DestinationNotificationMessage,
		[Parameter(Mandatory=$false)]
		[Nullable[DateTime]]$ScheduledStartTime = $null,
		[Parameter(Mandatory=$false)]
		[switch]$PassThru
    )

    process
    {
        CheckProjectIsSet

        $TaskObj = Get-OdmTaskOrThrow -Id $Task._id

		if ($TaskObj)
		{
			if ($SwitchDirection) { $TaskObj.SwitchDirection = GetEnumStringValue -EnumValue $SwitchDirection }

			foreach ($parameter in $PsBoundParameters.Keys)
			{
				switch ($parameter)
				{
					"Task" { break }
					"PassThru" { break }

					"ScheduledStartTime" { ConfigureScheduling $TaskObj $ScheduledStartTime; break }

					"SwitchDirection" { $TaskObj."$parameter" = GetEnumStringValue -EnumValue $PsBoundParameters[$parameter]; break }

					default {
						$TaskObj."$parameter" = $PsBoundParameters[$parameter]
					}
				}
			}

			# task create
			Set-QmmpEntity -EntityType 'tasks' -Entity $TaskObj -PassThru:$PassThru
		}
	}
}

function New-OdmCalendarSharingTask
{
    [CmdletBinding()]
    [OutputType([OdmCalendarSharingTask])]
    param(
		[Parameter(Mandatory=$false)]
		[ValidateNotNullOrEmpty()]
        [string]$Name = 'Calendar Sharing Task',
        [Parameter(Mandatory=$false)]
		[string]$SourceDomain,
        [Parameter(Mandatory=$false)]
		[string]$TargetDomain,
		[Parameter(Mandatory=$false)]
		[Nullable[DateTime]]$ScheduledStartTime = $null
    )

    process
    {
        CheckProjectIsSet

        $properties = GetNewTaskCommonProperties -TaskType 'Calendar Sharing' -StartTime $ScheduledStartTime

		$properties += @{
			Name = $Name;

            SourceDomain = if ($SourceDomain) { $SourceDomain } else { $script:OdmCurrentProject.SourceTenantDefaultDomainName };
            TargetDomain = if ($TargetDomain) { $TargetDomain } else { $script:OdmCurrentProject.TargetTenantDefaultDomainName };

			SourceConnectionId = "$($script:OdmCurrentProject._Id)-source";
            TargetConnectionId = "$($script:OdmCurrentProject._Id)-target";
		}

        # task create
		$Task = [OdmCalendarSharingTask] $properties

        New-QmmpEntity -EntityType 'tasks' -Entity $Task -PassThru
    }
}

function Set-OdmCalendarSharingTask
{
    [CmdletBinding()]
    [OutputType([OdmCalendarSharingTask])]
    param(
        [Parameter(Mandatory=$true, ValueFromPipeline=$true)]
        [OdmTask]$Task,
		[Parameter(Mandatory=$false)]
		[ValidateNotNullOrEmpty()]
        [string]$Name = 'Calendar Sharing Task',
        [Parameter(Mandatory=$false)]
		[string]$SourceDomain,
        [Parameter(Mandatory=$false)]
		[string]$TargetDomain,
		[Parameter(Mandatory=$false)]
		[Nullable[DateTime]]$ScheduledStartTime = $null,
		[Parameter(Mandatory=$false)]
		[switch]$PassThru
    )

    process
    {
        CheckProjectIsSet

        $TaskObj = Get-OdmTaskOrThrow -Id $Task._id

		if ($TaskObj)
		{
			foreach ($parameter in $PsBoundParameters.Keys)
			{
				switch ($parameter)
				{
					"Task" { break }
					"PassThru" { break }

					"ScheduledStartTime" { ConfigureScheduling $TaskObj $ScheduledStartTime; break }

					default {
						$TaskObj."$parameter" = $PsBoundParameters[$parameter]
					}
				}
			}

			# task create
			Set-QmmpEntity -EntityType 'tasks' -Entity $TaskObj -PassThru:$PassThru
		}
    }
}

function New-OdmProcessingTask
{
    [CmdletBinding()]
    [OutputType([OdmProcessingTask])]
    param(
        [Parameter(Mandatory=$false)]
		[ValidateNotNullOrEmpty()]
        [string]$Name = 'Resource Processing Task',
		[Parameter(Mandatory=$false)]
		[switch]$ProcessApplications,
        [Parameter(Mandatory=$false)]
		[switch]$ProcessRoles,
        [Parameter(Mandatory=$false)]
		[string]$SharePointSiteUrl,
		[Parameter(Mandatory=$false)]
		[Nullable[DateTime]]$ScheduledStartTime = $null
    )

    process
    {
        CheckProjectIsSet

        $properties = GetNewTaskCommonProperties -TaskType 'Resource Processing' -StartTime $ScheduledStartTime

		$properties += @{
			Name = $Name;

            ProcessApplications = $ProcessApplications;
            ProcessRoles = $ProcessRoles;
            SharePointSiteUrl = $SharePointSiteUrl;
		}

		if ($SharePointSiteUrl)
		{
			$properties += @{
				ProcessSharePoint = $true;
			}
		}
		else
		{
			$properties += @{
				ProcessSharePoint = $false;
			}
		}

        # task create
		$Task = [OdmProcessingTask] $properties

        New-QmmpEntity -EntityType 'tasks' -Entity $Task -PassThru

		Write-Warning $MessagesDictionary['AddObjects']
    } 
}

function Set-OdmProcessingTask
{
    [CmdletBinding()]
    [OutputType([OdmProcessingTask])]
    param(
        [Parameter(Mandatory=$true, ValueFromPipeline=$true)]
        [OdmTask]$Task,
		[Parameter(Mandatory=$false)]
		[ValidateNotNullOrEmpty()]
        [string]$Name = 'Resource Processing Task',
        [Parameter(Mandatory=$false)]
		[switch]$ProcessApplications,
        [Parameter(Mandatory=$false)]
		[switch]$ProcessRoles,
        [Parameter(Mandatory=$false)]
		[string]$SharePointSiteUrl,
		[Parameter(Mandatory=$false)]
		[Nullable[DateTime]]$ScheduledStartTime = $null,
		[Parameter(Mandatory=$false)]
		[switch]$PassThru
    )

    process
    {
        CheckProjectIsSet

        $TaskObj = Get-OdmTaskOrThrow -Id $Task._Id

		if ($TaskObj)
		{
			foreach ($parameter in $PsBoundParameters.Keys)
			{
				switch ($parameter)
				{
					"Task" { break }
					"PassThru" { break }

					"ScheduledStartTime" { ConfigureScheduling $TaskObj $ScheduledStartTime; break }

					default {
						$TaskObj."$parameter" = $PsBoundParameters[$parameter]
					}
				}
			}

			if ($SharePointSiteUrl) { 
				$TaskObj.ProcessSharePoint = $true
			}
			else {
				$TaskObj.ProcessSharePoint = $false
			}

			# task create
			Set-QmmpEntity -EntityType 'tasks' -Entity $TaskObj -PassThru:$PassThru
		}
    } 
}

function New-OdmMappingFileTask
{
    [CmdletBinding()]
    [OutputType([OdmMappingFileTask])]
    param(
        [Parameter(Mandatory=$false)]
		[ValidateNotNullOrEmpty()]
        [string]$Name = 'Mapping from File Task',
		[Parameter(Mandatory=$true)]
		[string]$FilePath,
		[Parameter(Mandatory=$false)]
		[Nullable[DateTime]]$ScheduledStartTime = $null
    )

    process
    {
        CheckProjectIsSet

        $fileId = UploadFile -FilePath $FilePath
        $fileName = [System.IO.Path]::GetFileName($FilePath)

        $properties = GetNewTaskCommonProperties -TaskType 'Mapping from File' -StartTime $ScheduledStartTime

		$properties += @{
			Name = $Name;

            MatchingAction = 'MatchingFromFile';
            
            MatchingFile = @{ filename = $fileName; id = $fileId; url = "/api/files/$fileId/download"; }

			TargetConnectionId = "$($script:OdmCurrentProject._Id)-target";
		}

        # task create
		$Task = [OdmMappingFileTask] $properties

        New-QmmpEntity -EntityType 'tasks' -Entity $Task -PassThru
    } 
}

function Set-OdmMappingFileTask
{
    [CmdletBinding()]
    [OutputType([OdmMappingFileTask])]
    param(
        [Parameter(Mandatory=$true, ValueFromPipeline=$true)]
        [OdmTask]$Task,
		[Parameter(Mandatory=$false)]
		[ValidateNotNullOrEmpty()]
        [string]$Name = 'Mapping from File Task',
        [Parameter(Mandatory=$true)]
		[string]$FilePath,
		[Parameter(Mandatory=$false)]
		[Nullable[DateTime]]$ScheduledStartTime = $null,
		[Parameter(Mandatory=$false)]
		[switch]$PassThru
    )

    process
    {
        CheckProjectIsSet

        $TaskObj = Get-OdmTaskOrThrow -Id $Task._id

		if ($TaskObj)
		{
			if ($FilePath)
			{
				$fileId = UploadFile -FilePath $FilePath
				$fileName = [System.IO.Path]::GetFileName($FilePath)

				$TaskObj.MatchingFile = @{ filename = $fileName; id = $fileId; url = "/api/files/$fileId/download"; }
			}
		

			foreach ($parameter in $PsBoundParameters.Keys)
			{
				switch ($parameter)
				{
					"Task" { break }
					"PassThru" { break }
					"FilePath" { break }

					"ScheduledStartTime" { ConfigureScheduling $TaskObj $ScheduledStartTime; break }

					default {
						$TaskObj."$parameter" = $PsBoundParameters[$parameter]
					}
				}
			}

			# task create
			Set-QmmpEntity -EntityType 'tasks' -Entity $TaskObj -PassThru:$PassThru
		}
    } 
}

function Split-File
{
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
		[string]$FilePath,
        [Parameter(Mandatory=$false)]
		[int]$NoOfRowsInEachFile = 1,
        [Parameter(Mandatory=$false)]
		[bool]$HeaderExists = $true,
        [Parameter(Mandatory=$false)]
		[string]$SubFolderName = 'CopyPermission',
        [Parameter(Mandatory=$true)]
		[string]$PrefixFileName
    )

    $currentDirectory = (Get-Location).Path
    $folder = New-Item -Path $currentDirectory -Name $SubFolderName -ItemType Directory -Force

    $rows = Get-Content -Path $FilePath

    $fileCounter=0;
    $index = -1;
    if($HeaderExists)
    {
        $header = $rows[0]
        $index =0;
    }

    do
    {
        $fileCounter++;
        $fileName = "$($currentDirectory)\$($SubFolderName)\$($PrefixFileName)$fileCounter.csv";
        Set-Content -path $fileName -value $header -Force; 
        for($i=1;$i -le $NoOfRowsInEachFile; $i++)
        {
            $index++
            if($index -ge $rows.Length)
            {
                break;
            }
            Add-Content -path $fileName -value $rows[$index]
        }
    } while(($index + 1) -lt $rows.Length)
}

function New-OdmCopyPermission-SplitAndProcessTask
{
    [CmdletBinding()]
    [OutputType([OdmCopyPermissionTask])]
    param(
		[Parameter(Mandatory=$true)]
		[string]$UsersFilePath,	
        
        [Parameter(Mandatory=$true)]
		[string]$SharePointSitesPath
    )

    process
    {
        CheckProjectIsSet

		$NoOfRowsInSharePointSiteFile = 25
		$NoOfRowsInUserFile = 25

        $randomNumber=Get-Random -Minimum 10000 -Maximum 99999
         
        Split-File -FilePath $UsersFilePath -NoOfRowsInEachFile $NoOfRowsInUserFile -HeaderExists $true -SubFolderName "CopyPermission$randomNumber" -PrefixFileName UserFile

        Split-File -FilePath $SharePointSitesPath -NoOfRowsInEachFile $NoOfRowsInSharePointSiteFile -HeaderExists $false -SubFolderName "CopyPermission$randomNumber" -PrefixFileName SharePointSiteFile

        $currentDirectory = (Get-Location).Path

        $allUserFiles = Get-ChildItem -Path "$($currentDirectory)\CopyPermission$($randomNumber)" -Filter UserFile*.csv
        $allSharePointFiles = Get-ChildItem  -Path "$($currentDirectory)\CopyPermission$($randomNumber)" -Filter SharePointSiteFile*.csv

        foreach($user in $allUserFiles)
        {
            foreach($site in $allSharePointFiles)
            {
                $cpTask = New-OdmCopyPermissionTask -UsersFilePath $user.FullName -SharePointSitesPath $site.FullName -Name "Copy Permission - $($user.Name) - $($site.Name)"

                Start-OdmTask -Tasks $cpTask

                Write-Host "Task Started for $($user.Name) - $($site.Name)"

                do
                {
                    Start-Sleep -Seconds 60
                    $taskStatus = (Get-OdmTask $cpTask._Id).Status
                } while(($taskStatus -eq 'In Progress'))

                if($taskStatus -eq 'Completed')
                {
                    Write-Host "Task $taskStatus for $($user.Name) - $($site.Name)" -ForegroundColor Green
                }
                else
                {
                    Write-Host "Task $taskStatus for $($user.Name) - $($site.Name)" -ForegroundColor Red
                }
            }
        }
    } 
}

function New-OdmCopyPermissionTask
{
    [CmdletBinding()]
    [OutputType([OdmCopyPermissionTask])]
    param(
        [Parameter(Mandatory=$false)]
		[ValidateNotNullOrEmpty()]
        [string]$Name = 'Copy Permission Task',
		[Parameter(Mandatory=$true)]
		[string]$UsersFilePath,	
		[Parameter(Mandatory=$false)]
		[string]$SharePointSitesPath,
		[Parameter(Mandatory=$false)]
		[string]$SharePointSiteUrl = '',	
		[Parameter(Mandatory=$false)]
		[Nullable[DateTime]]$ScheduledStartTime = $null
    )

    process
    {
        CheckProjectIsSet

        $usersFileId = UploadFile -FilePath $UsersFilePath
        $usersFileName = [System.IO.Path]::GetFileName($UsersFilePath)
		
		if($SharePointSitesPath)
		{
			$sharepointSitesFileId = UploadFile -FilePath $SharePointSitesPath
			$sharepointSitesFileName = [System.IO.Path]::GetFileName($SharePointSitesPath)
			
			$ProcessMultipleSharepointSites = 'specifiedSPFile'
		}
        elseif($SharePointSiteUrl -eq '')
        {
            $ProcessMultipleSharepointSites = 'allSharepoint'
        }
		else
        {
            $ProcessMultipleSharepointSites = 'specifiedSite'
        }

        $properties = GetNewTaskCommonProperties -TaskType 'Copy Permission' -StartTime $ScheduledStartTime

		$properties += @{
			Name = $Name;
           
            TransferPermissionsFile = @{ filename = $usersFileName; id = $usersFileId; url = "/api/files/$usersFileId/download"; }
			
			SharepointMultipleUrlFile = @{ filename = $sharepointSitesFileName; id = $sharepointSitesFileId; url = "/api/files/$sharepointSitesFileId/download"; }
			
			ProcessSharePoint = $true;
			
			SharePointSiteUrl = $SharePointSiteUrl;
			
			ProcessMultipleSharepointSites = $ProcessMultipleSharepointSites
		}

        # task create
		$Task = [OdmCopyPermissionTask] $properties

        New-QmmpEntity -EntityType 'tasks' -Entity $Task -PassThru
    } 
}

function New-OdmOneDriveMigrationTask
{
    [CmdletBinding()]
    [OutputType([OdmOneDriveMigrationTask])]
    param(
        [Parameter(Mandatory=$false)]
		[ValidateNotNullOrEmpty()]
        [string]$Name = 'OneDrive Migration Task',
		[Parameter(Mandatory=$false)]
        [OneDriveFileVersionsEnum]$FileVersions = 'Latest',
        [Parameter(Mandatory=$false)]
        [OneDriveMigrationActionEnum]$MigrationAction = 'Skip',
        [Parameter(Mandatory=$false)]
		[OneDrivePermissionBehaviourEnum]$PermissionBehaviour = 'NoPermission',
        [Parameter(Mandatory=$false)]
		[switch]$MigrateLinkPermission,
        [Parameter(Mandatory=$false)]
		[OneDriveAuthorEnum]$Author = 'SystemAccount',
        [Parameter(Mandatory=$false)]
        [ValidateRange(32,512)]
        [long]$FileVersionMaxSize = 80,
        
		[Parameter(Mandatory=$false)]
		[bool]$RerunIfMissingItems = $true,
        
        [Parameter(Mandatory=$false)]
        [string]$ExcludeFolders,
        [Parameter(Mandatory=$false)]
        [string]$ExcludeFileTypes,
        [Parameter(Mandatory=$false)]
        [Nullable[DateTime]]$ExcludeCreatedBefore,
        [Parameter(Mandatory=$false)]
        [Nullable[DateTime]]$ExcludeModifiedAfter,
        [Parameter(Mandatory=$false)]
        [Nullable[long]]$ExcludeBiggerThan = $null,

        [Parameter(Mandatory=$true)]
		[string]$O365LicenseToAssign,
		[Parameter(Mandatory=$true)]
		[O365LicenseAssignmentTypeEnum]$O365LicenseAssignmentType,
		[Parameter(Mandatory=$false)]
		[bool]$OverrideUsageLocation,
		[Parameter(Mandatory=$false)]
		[UsageLocation]$UsageLocation,

		[Parameter(Mandatory=$false)]
		[Nullable[DateTime]]$ScheduledStartTime = $null
    )

    process
    {
        CheckProjectIsSet

        $properties = GetNewTaskCommonProperties -TaskType 'OneDrive Migration' -StartTime $ScheduledStartTime

        $strPermissionBehaviour = GetEnumStringValue -EnumValue $PermissionBehaviour -InLowerCase;
        if ($strPermissionBehaviour -eq "nopermission" -and $MigrateLinkPermission -eq $true)
		{
            throw "Invalid sharelink migration settings."
		}

		$properties += @{
			Name = $Name;

            FileVersions = GetEnumStringValue -EnumValue $FileVersions;
            MigrationAction = GetEnumStringValue -EnumValue $MigrationAction;
            PermissionBehaviour = GetEnumStringValue -EnumValue $PermissionBehaviour;
            Author = GetEnumStringValue -EnumValue $Author;
            RerunIfMissingItems = $RerunIfMissingItems;

            MigrateLinkPermission = $MigrateLinkPermission;
            ExcludeFolders = $ExcludeFolders;
            ExcludeFileTypes = $ExcludeFileTypes;
            ExcludeCreatedBefore = GetUniversalTime -Value $ExcludeCreatedBefore;
            ExcludeModifiedAfter = GetUniversalTime -Value $ExcludeModifiedAfter;

            O365LicenseToAssign = $O365LicenseToAssign;
            O365LicenseAssignmentType = GetEnumStringValue -EnumValue $O365LicenseAssignmentType;

			TargetConnectionId = "$($script:OdmCurrentProject._Id)-target";

            OverrideUsageLocation = $OverrideUsageLocation
            UsageLocation = GetEnumStringValue -EnumValue $UsageLocation
		}
         
        $fileVers = GetEnumStringValue -EnumValue $FileVersions -InLowerCase
        if ($fileVers -eq "latest") 
        { 
            $properties += @{ FileVersionMaxSize = 80 }
        } else { 
            $properties += @{ FileVersionMaxSize = $FileVersionMaxSize } 
        }

		if ($ExcludeBiggerThan -gt 0)
		{
			$properties += @{
				ExcludeBiggerThan = $ExcludeBiggerThan;
			}
		}
        # task create
		$Task = [OdmOneDriveMigrationTask] $properties

        New-QmmpEntity -EntityType 'tasks' -Entity $Task -PassThru

		Write-Warning $MessagesDictionary['AddObjects']
    } 

    <#
		.PARAMETER  OverrideUsageLocation
			Overwrite existing target value of UsageLocation.
		.PARAMETER  UsageLocation
			By default the source value for UsageLocation is used. A custom value can be set for target instead.
	#>

}

function Set-OdmOneDriveMigrationTask
{
    [CmdletBinding()]
    [OutputType([OdmOneDriveMigrationTask])]
    param(
        [Parameter(Mandatory=$true, ValueFromPipeline=$true)]
        [OdmTask]$Task,
		[Parameter(Mandatory=$false)]
		[ValidateNotNullOrEmpty()]
        [string]$Name = 'OneDrive Migration Task',
        [Parameter(Mandatory=$false)]
        [OneDriveFileVersionsEnum]$FileVersions,
        [Parameter(Mandatory=$false)]
        [OneDriveMigrationActionEnum]$MigrationAction,
        [Parameter(Mandatory=$false)]
		[OneDrivePermissionBehaviourEnum]$PermissionBehaviour,
        [Parameter(Mandatory=$false)]
		[switch]$MigrateLinkPermission,
        [Parameter(Mandatory=$false)]
		[OnedriveAuthorEnum]$Author,
		[Parameter(Mandatory=$false)]
		[bool]$RerunIfMissingItems,
        [Parameter(Mandatory=$false)]
        [ValidateRange(32,512)]
        [long]$FileVersionMaxSize,
  
        [Parameter(Mandatory=$false)]
        [string]$ExcludeFolders,
        [Parameter(Mandatory=$false)]
        [string]$ExcludeFileTypes,
        [Parameter(Mandatory=$false)]
        [Nullable[DateTime]]$ExcludeCreatedBefore,
        [Parameter(Mandatory=$false)]
        [Nullable[DateTime]]$ExcludeModifiedAfter,
        [Parameter(Mandatory=$false)]
        [Nullable[long]]$ExcludeBiggerThan = $null,

        [Parameter(Mandatory=$false)]
		[string]$O365LicenseToAssign,
		[Parameter(Mandatory=$false)]
		[O365LicenseAssignmentTypeEnum]$O365LicenseAssignmentType,
		[Parameter(Mandatory=$false)]
		[bool]$OverrideUsageLocation,
		[Parameter(Mandatory=$false)]
		[UsageLocation]$UsageLocation,

		[Parameter(Mandatory=$false)]
		[Nullable[DateTime]]$ScheduledStartTime = $null,
		[Parameter(Mandatory=$false)]
		[switch]$PassThru
    )

    process
    {
        CheckProjectIsSet

		$TaskObj = Get-OdmTaskOrThrow -Id $Task._id

        $strPermissionBehaviour = GetEnumStringValue -EnumValue $PermissionBehaviour -InLowerCase;
        if ($strPermissionBehaviour -eq "nopermission" -and $MigrateLinkPermission -eq $true)
		{
            throw "Invalid sharelink migration settings."
		}

		if ($TaskObj)
		{
			foreach ($parameter in $PsBoundParameters.Keys)
			{
				switch ($parameter)
				{
					"Task" { break }
					"PassThru" { break }

					"ScheduledStartTime" { ConfigureScheduling $TaskObj $ScheduledStartTime; break }

					"O365LicenseAssignmentType" { $TaskObj."$parameter" = GetEnumStringValue -EnumValue $PsBoundParameters[$parameter]; break }

					"ExcludeCreatedBefore" { $TaskObj."$parameter" = GetUniversalTime -Value $ExcludeCreatedBefore; break }
					"ExcludeModifiedAfter" { $TaskObj."$parameter" = GetUniversalTime -Value $ExcludeModifiedAfter; break }

					"FileVersions" { $TaskObj."$parameter" = GetEnumStringValue -EnumValue $PsBoundParameters[$parameter]; break }
					"MigrationAction" { $TaskObj."$parameter" = GetEnumStringValue -EnumValue $PsBoundParameters[$parameter]; break }
                    "PermissionBehaviour" { $TaskObj."$parameter" = GetEnumStringValue -EnumValue $PsBoundParameters[$parameter]; break }

                    "Author" { $TaskObj."$parameter" = GetEnumStringValue -EnumValue $PsBoundParameters[$parameter]; break }

                    "UsageLocation" { $TaskObj."$parameter" = GetEnumStringValue -EnumValue $PsBoundParameters[$parameter]; break }
     
                    "FileVersionMaxSize" {
                        $fileVers = GetEnumStringValue -EnumValue $FileVersions -InLowerCase
                        if ($fileVers -eq "latest") { $TaskObj."$parameter" = 80; break } 
                        else { $TaskObj."$parameter" = $PsBoundParameters[$parameter]; break }
                    }
                                                                                                    
					"ExcludeBiggerThan" {
						if ($ExcludeBiggerThan -gt 0) { $TaskObj."$parameter" = $PsBoundParameters[$parameter] }
					}

					default {
						$TaskObj."$parameter" = $PsBoundParameters[$parameter]
					}
				}
			}

			# task create
			Set-QmmpEntity -EntityType 'tasks' -Entity $TaskObj -PassThru:$PassThru
		}
    } 

    <#
		.PARAMETER  OverrideUsageLocation
			Overwrite existing target value of UsageLocation.
		.PARAMETER  UsageLocation
			By default the source value for UsageLocation is used. A custom value can be set for target instead.
	#>

}

function New-OdmOneDriveStatisticsTask
{
    [CmdletBinding()]
    [OutputType([OdmOneDriveStatisticsTask])]
    param(
		[Parameter(Mandatory=$false)]
		[ValidateNotNullOrEmpty()]
        [string]$Name = 'OneDrive Collect Statistics Task',
		[Parameter(Mandatory=$false)]
		[Nullable[DateTime]]$ScheduledStartTime = $null
    )

    process
    {
        CheckProjectIsSet

        $properties = GetNewTaskCommonProperties -TaskType 'OneDrive Assessment' -StartTime $ScheduledStartTime

        $properties += @{
			Name = $Name;

		}

        # task create
		$Task = [OdmOneDriveStatisticsTask] $properties

        New-QmmpEntity -EntityType 'tasks' -Entity $Task -PassThru

        Write-Warning $MessagesDictionary['AddObjects']
    } 
}

function Set-OdmOneDriveStatisticsTask
{
    [CmdletBinding()]
    [OutputType([OdmOneDriveStatisticsTask])]
    param(
        [Parameter(Mandatory=$true, ValueFromPipeline=$true)]
        [OdmTask]$Task,
		[Parameter(Mandatory=$false)]
		[ValidateNotNullOrEmpty()]
        [string]$Name = 'OneDrive Collect Statistics Task',
		[Parameter(Mandatory=$false)]
		[Nullable[DateTime]]$ScheduledStartTime = $null,
		[Parameter(Mandatory=$false)]
		[switch]$PassThru
    )

    process
    {
        CheckProjectIsSet

        $TaskObj = Get-OdmTaskOrThrow -Id $Task._id

		if ($TaskObj)
		{
			foreach ($parameter in $PsBoundParameters.Keys)
			{
				switch ($parameter)
				{
					"Task" { break }
					"PassThru" { break }

					"ScheduledStartTime" { ConfigureScheduling $TaskObj $ScheduledStartTime; break }

					default {
						$TaskObj."$parameter" = $PsBoundParameters[$parameter]
					}
				}
			}

			# task create
			Set-QmmpEntity -EntityType 'tasks' -Entity $TaskObj -PassThru:$PassThru
		}
    } 
}

function New-OdmAddressRewritingTask
{
    [CmdletBinding()]
    [OutputType([OdmAddressRewritingTask])]
    param(
		[Parameter(Mandatory=$false)]
		[ValidateNotNullOrEmpty()]
        [string]$Name = 'Address Rewriting Task',
        [Parameter(Mandatory=$true)]
		[AddressRewritingActionEnum]$Action
    )

    process
    {
        CheckProjectIsSet

		$existingTasks = Get-OdmTask -Type "Address Rewriting"

		if ($Action -eq [AddressRewritingActionEnum]::Enable -and -not (IsAddressRewritingProvisioned -ExistingTasks $existingTasks))
		{
			throw $MessagesDictionary['TaskNotAllowed']
		}
		elseif ($Action -eq [AddressRewritingActionEnum]::Disable -and -not (IsAddressRewritingProvisioned -OrFailed -ExistingTasks $existingTasks))
		{
			throw $MessagesDictionary['TaskNotAllowed']
		}
		elseif (CanProvisionAddressRewriting -Action $Action -ExistingTasks $existingTasks)
		{
			throw $MessagesDictionary['TaskAlreadyDone']
		}
		else
		{
			$properties = GetNewTaskCommonProperties -TaskType 'Address Rewriting'

			$properties += @{
				Name = $Name;

				Action = GetEnumStringValue -EnumValue $Action;

				SourceConnectionId = "$($script:OdmCurrentProject._Id)-source";
				TargetConnectionId = "$($script:OdmCurrentProject._Id)-target";
			}

			if ($Action -eq [AddressRewritingActionEnum]::Deploy -or $Action -eq [AddressRewritingActionEnum]::DeployReverse -or $Action -eq [AddressRewritingActionEnum]::Enable -or $Action -eq [AddressRewritingActionEnum]::Disable)
			{
				$postfix = if ($Action -eq [AddressRewritingActionEnum]::Deploy -or $Action -eq [AddressRewritingActionEnum]::DeployReverse) { 'DeployARS' } else { 'SwitchARS' }

				$properties += @{
					_Id = "$($script:OdmCurrentProject._Id)-$postfix";

					Hidden = $true;
				}

				$properties['Run'] = GetEnumStringValue -EnumValue ([RunTaskEnum]::Now) -StartsInLowerCase
			}

			# task create
			$Task = [OdmAddressRewritingTask] $properties

			if ($Task._Id)
			{
				Set-QmmpEntity -EntityType 'tasks' -Entity $Task -PassThru -StartTaskIfNow
			}
			else
			{
				New-QmmpEntity -EntityType 'tasks' -Entity $Task -PassThru

				Write-Warning $MessagesDictionary['AddObjects']
			}
		}
    } 
}

# SIG # Begin signature block
# MIIOBwYJKoZIhvcNAQcCoIIN+DCCDfQCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUbDjStTdS1gAx5p3qMMWQUIF0
# +sOgggs9MIIFVTCCBD2gAwIBAgIRAOQ7pk6be99ARw7gugXITCQwDQYJKoZIhvcN
# AQELBQAwfTELMAkGA1UEBhMCR0IxGzAZBgNVBAgTEkdyZWF0ZXIgTWFuY2hlc3Rl
# cjEQMA4GA1UEBxMHU2FsZm9yZDEaMBgGA1UEChMRQ09NT0RPIENBIExpbWl0ZWQx
# IzAhBgNVBAMTGkNPTU9ETyBSU0EgQ29kZSBTaWduaW5nIENBMB4XDTE5MTAwMjAw
# MDAwMFoXDTIxMTAwMTIzNTk1OVowgZwxCzAJBgNVBAYTAlVTMQ4wDAYDVQQRDAU5
# MjY1NjETMBEGA1UECAwKQ2FsaWZvcm5pYTEUMBIGA1UEBwwLQWxpc28gVmllam8x
# FjAUBgNVBAkMDTQgUG9sYXJpcyBXYXkxHDAaBgNVBAoME1F1ZXN0IFNvZnR3YXJl
# IEluYy4xHDAaBgNVBAMME1F1ZXN0IFNvZnR3YXJlIEluYy4wggEiMA0GCSqGSIb3
# DQEBAQUAA4IBDwAwggEKAoIBAQC0QLBHHs0mb9AKSmxaUJ9vjDn5zvnhNZjHt3ud
# +qn8/yX1ddNp/eRflK1NWm6/RfIxjWfHl45rGRR3AlQKjR7CcxZsLBuhm449vlgA
# hIn5TNsFE8U/4V2m5YoVH9ET2TJgPEmUs9TsJwyA1YYWdVoZ4TfPMG7DHlpla1+R
# LKUeztF/UZm+q2qxYbSCaDZEiRaUEJ9TvgXa9eiQZOktAcoN9fuzuJW8HgHT6snH
# 2mzuJjR8JofbMm+APm3Qg3bMgGnlv1/UKu3TdniMwgwK2HZNf6qlhm5jP6s+256l
# 64GojJP4Z6HmWnFbVD0EXH7atY6s7l+Jz//d/6Y0adRGUpxJAgMBAAGjggGuMIIB
# qjAfBgNVHSMEGDAWgBQpkWD/ik366/mmarjP+eZLvUnOEjAdBgNVHQ4EFgQUbP9G
# anzu1CKGvG28iLn2zJdWfjcwDgYDVR0PAQH/BAQDAgeAMAwGA1UdEwEB/wQCMAAw
# EwYDVR0lBAwwCgYIKwYBBQUHAwMwEQYJYIZIAYb4QgEBBAQDAgQQMEAGA1UdIAQ5
# MDcwNQYMKwYBBAGyMQECAQMCMCUwIwYIKwYBBQUHAgEWF2h0dHBzOi8vc2VjdGln
# by5jb20vQ1BTMEMGA1UdHwQ8MDowOKA2oDSGMmh0dHA6Ly9jcmwuY29tb2RvY2Eu
# Y29tL0NPTU9ET1JTQUNvZGVTaWduaW5nQ0EuY3JsMHQGCCsGAQUFBwEBBGgwZjA+
# BggrBgEFBQcwAoYyaHR0cDovL2NydC5jb21vZG9jYS5jb20vQ09NT0RPUlNBQ29k
# ZVNpZ25pbmdDQS5jcnQwJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3NwLmNvbW9kb2Nh
# LmNvbTAlBgNVHREEHjAcgRptaWNoYWVsLmdvcm9jaGl0QHF1ZXN0LmNvbTANBgkq
# hkiG9w0BAQsFAAOCAQEADLM1M9Xa7P0bAl0U8XK+IH1RkQtIrQ9S/prL8oEgzKdZ
# zE9Q+eGUjxth0UeWje1PTRwMrU9Iu0JpiTyGsQf8+sVPm2Asg2eXKs7c+CuhRzfS
# e+HhaoKRGqC/1WNxQDeNwQbtqpLxwLukSnzTDZnCHB2bQGdJiER8+fQ6KwhxKvg8
# wZEWBs52s7U1jFu1mQsOOnXA9G0aFie1xaxN7XPny+6rsrgSeK6CGtTIwLW3VbgS
# bSPRB4IhGFzKxOuBYXLmmrX9m437MwBw9yiIOWoouGbK+Gc+2UcmzcVLvtdSj44B
# J9NcgGlzHH4P5mKDLN+gSroMm0TWOL+bg1y4B6hupDCCBeAwggPIoAMCAQICEC58
# h8wOk0pS/pT9HLfNNK8wDQYJKoZIhvcNAQEMBQAwgYUxCzAJBgNVBAYTAkdCMRsw
# GQYDVQQIExJHcmVhdGVyIE1hbmNoZXN0ZXIxEDAOBgNVBAcTB1NhbGZvcmQxGjAY
# BgNVBAoTEUNPTU9ETyBDQSBMaW1pdGVkMSswKQYDVQQDEyJDT01PRE8gUlNBIENl
# cnRpZmljYXRpb24gQXV0aG9yaXR5MB4XDTEzMDUwOTAwMDAwMFoXDTI4MDUwODIz
# NTk1OVowfTELMAkGA1UEBhMCR0IxGzAZBgNVBAgTEkdyZWF0ZXIgTWFuY2hlc3Rl
# cjEQMA4GA1UEBxMHU2FsZm9yZDEaMBgGA1UEChMRQ09NT0RPIENBIExpbWl0ZWQx
# IzAhBgNVBAMTGkNPTU9ETyBSU0EgQ29kZSBTaWduaW5nIENBMIIBIjANBgkqhkiG
# 9w0BAQEFAAOCAQ8AMIIBCgKCAQEAppiQY3eRNH+K0d3pZzER68we/TEds7liVz+T
# vFvjnx4kMhEna7xRkafPnp4ls1+BqBgPHR4gMA77YXuGCbPj/aJonRwsnb9y4+R1
# oOU1I47Jiu4aDGTH2EKhe7VSA0s6sI4jS0tj4CKUN3vVeZAKFBhRLOb+wRLwHD9h
# YQqMotz2wzCqzSgYdUjBeVoIzbuMVYz31HaQOjNGUHOYXPSFSmsPgN1e1r39qS/A
# JfX5eNeNXxDCRFU8kDwxRstwrgepCuOvwQFvkBoj4l8428YIXUezg0HwLgA3FLkS
# qnmSUs2HD3vYYimkfjC9G7WMcrRI8uPoIfleTGJ5iwIGn3/VCwIDAQABo4IBUTCC
# AU0wHwYDVR0jBBgwFoAUu69+Aj36pvE8hI6t7jiY7NkyMtQwHQYDVR0OBBYEFCmR
# YP+KTfrr+aZquM/55ku9Sc4SMA4GA1UdDwEB/wQEAwIBhjASBgNVHRMBAf8ECDAG
# AQH/AgEAMBMGA1UdJQQMMAoGCCsGAQUFBwMDMBEGA1UdIAQKMAgwBgYEVR0gADBM
# BgNVHR8ERTBDMEGgP6A9hjtodHRwOi8vY3JsLmNvbW9kb2NhLmNvbS9DT01PRE9S
# U0FDZXJ0aWZpY2F0aW9uQXV0aG9yaXR5LmNybDBxBggrBgEFBQcBAQRlMGMwOwYI
# KwYBBQUHMAKGL2h0dHA6Ly9jcnQuY29tb2RvY2EuY29tL0NPTU9ET1JTQUFkZFRy
# dXN0Q0EuY3J0MCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5jb21vZG9jYS5jb20w
# DQYJKoZIhvcNAQEMBQADggIBAAI/AjnD7vjKO4neDG1NsfFOkk+vwjgsBMzFYxGr
# CWOvq6LXAj/MbxnDPdYaCJT/JdipiKcrEBrgm7EHIhpRHDrU4ekJv+YkdK8eexYx
# biPvVFEtUgLidQgFTPG3UeFRAMaH9mzuEER2V2rx31hrIapJ1Hw3Tr3/tnVUQBg2
# V2cRzU8C5P7z2vx1F9vst/dlCSNJH0NXg+p+IHdhyE3yu2VNqPeFRQevemknZZAp
# QIvfezpROYyoH3B5rW1CIKLPDGwDjEzNcweU51qOOgS6oqF8H8tjOhWn1BUbp1JH
# Mqn0v2RH0aofU04yMHPCb7d4gp1c/0a7ayIdiAv4G6o0pvyM9d1/ZYyMMVcx0Dbs
# R6HPy4uo7xwYWMUGd8pLm1GvTAhKeo/io1Lijo7MJuSy2OU4wqjtxoGcNWupWGFK
# Cpe0S0K2VZ2+medwbVn4bSoMfxlgXwyaiGwwrFIJkBYb/yud29AgyonqKH4yjhnf
# e0gzHtdl+K7J+IMUk3Z9ZNCOzr41ff9yMU2fnr0ebC+ojwwGUPuMJ7N2yfTm18M0
# 4oyHIYZh/r9VdOEhdwMKaGy75Mmp5s9ZJet87EUOeWZo6CLNuO+YhU2WETwJitB/
# vCgoE/tqylSNklzNwmWYBp7OSFvUtTeTRkF8B93P+kPvumdh/31J4LswfVyA4+YW
# OUunMYICNDCCAjACAQEwgZIwfTELMAkGA1UEBhMCR0IxGzAZBgNVBAgTEkdyZWF0
# ZXIgTWFuY2hlc3RlcjEQMA4GA1UEBxMHU2FsZm9yZDEaMBgGA1UEChMRQ09NT0RP
# IENBIExpbWl0ZWQxIzAhBgNVBAMTGkNPTU9ETyBSU0EgQ29kZSBTaWduaW5nIENB
# AhEA5DumTpt730BHDuC6BchMJDAJBgUrDgMCGgUAoHgwGAYKKwYBBAGCNwIBDDEK
# MAigAoAAoQKAADAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgorBgEEAYI3
# AgELMQ4wDAYKKwYBBAGCNwIBFTAjBgkqhkiG9w0BCQQxFgQUjRW3c83MCPJ1C6dw
# sKfEtW6GPLUwDQYJKoZIhvcNAQEBBQAEggEADK+3g1yya0TKg6fPszkD+ZCla509
# v5UnB8hx+deVMgP3DanKPbRJvRB5YNlHZQAOLdEioR2bMFsM/J6WeVSmDggRKqSf
# M9mnOj3wyzJToWFHz0xGLFbdWqnH6RnI9y2+QFScvZMmenKkMQFeZ3653Sa3W1d+
# epR/kXp1jw5kRwsP2fZmismPzA6JzzszLy/SPnGwlj6TaXEG0Tc3glY6nrYktns1
# dV1k18nCGImGUe3ma/ANiYKYMSH+y8ClmbR33KAkD9TDZVL53BfRv/1nyGZhU63q
# 2Fpcw1G2aXl9cOmCJGpQLgZh+bktTmByV3wIaduwBz+eJGPQJmNZsdVhkw==
# SIG # End signature block
